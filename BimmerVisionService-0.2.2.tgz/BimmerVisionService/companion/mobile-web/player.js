/**
 * BimmerVision Mobile Video Player & Cockpit HUD Controller
 * Hardware-accelerated decoding via WebCodecs VideoDecoder with Range-Streaming,
 * Bounded Memory Management, Camera Identity Mapping, and Real Telemetry Sync.
 */
function bvFetch(url, options) {
  options = options || {};
  var headers = Object.assign({}, options.headers || {});
  var bearer = sessionStorage.getItem("bimmervision_bearer");
  if (bearer && !headers.Authorization) headers.Authorization = "Bearer " + bearer;
  return fetch(url, Object.assign({ credentials: "include" }, options, { headers: headers }));
}

class BimmerVisionPlayer {
  static useNativePreview(available, secure, hasDecoder, forced) {
    return available && (forced || !secure || !hasDecoder);
  }
  constructor(canvas, hudElements) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d", { alpha: false });
    this.hud = hudElements;

    this.parser = null;
    this.assembler = null;
    this.accessUnits = [];
    this.manifest = null;
    this.bvrUrl = null;
    this.loadedByteOffset = 0;
    this.totalBytes = 0;
    this.isLoadingChunk = false;

    // Decoder & frame cache (bounded to ~50 frames max)
    this.decoder = null;
    this.decodedFrames = new Map(); // auIndex -> ImageBitmap
    this.lastFrFrame = null;
    this.lastLrFrame = null;

    // Camera pair identity & alignment mapping (Front/Rear vs Left/Right)
    this.cameraMapping = this._loadCameraMapping();

    // Playback state
    this.isPlaying = false;
    this.currentTime = 0;
    this.duration = 0;
    this.currentAuIndex = 0;
    this.speedUnit = "mph"; // or "km/h"
    this.currentSpeedLimit = null;
    this._speedLimitCache = new Map();
    this._lastSpeedLimitLookupCoord = null;
    this.viewMode = "quad"; // "quad", "source", "front", "rear", "left", "right"
    this.sedanSelector = null;
    this.liveMap = null;
    this.rafId = null;
    this.lastFrameWallTime = null;

    // Quad offscreen compositing canvas (1280x960)
    this.quadCanvas = document.createElement("canvas");
    this.quadCanvas.width = 1280;
    this.quadCanvas.height = 960;
    this.quadCtx = this.quadCanvas.getContext("2d", { alpha: false });
    this.quadCtx.fillStyle = "#11141a";
    this.quadCtx.fillRect(0, 0, 1280, 960);

    this._clipEpoch = 0;
    this._decoderEpoch = 0;
    this.playbackState = "idle";
    this.streamComplete = false;
    this.nextDecodeIdx = 0;
  }

  _loadCameraMapping(clipId = null) {
    try {
      const id = clipId || this.activeClipId;
      if (id) {
        const savedClip = localStorage.getItem("bimmervision_mapping_" + id);
        if (savedClip) return JSON.parse(savedClip);
      }
      const saved = localStorage.getItem("bimmervision_camera_mapping");
      if (saved) return JSON.parse(saved);
    } catch (_) {}
    return {
      phase0: "frontRear", // "frontRear" or "leftRight"
      phase1: "leftRight", // "leftRight" or "frontRear"
      flipHalves: false    // false: Left=0..640, Right=640..1280; true: inverted
    };
  }

  saveCameraMapping(mapping, clipId = null) {
    this.cameraMapping = Object.assign(this.cameraMapping || {}, mapping);
    const id = clipId || this.activeClipId;
    try {
      localStorage.setItem("bimmervision_camera_mapping", JSON.stringify(this.cameraMapping));
      if (id) {
        localStorage.setItem("bimmervision_mapping_" + id, JSON.stringify(this.cameraMapping));
      }
    } catch (_) {}
    this._renderFrameAtTime(this.currentTime);
  }

  _getCodecString() {
    if (this.assembler && this.assembler.sps && this.assembler.sps.length >= 4) {
      const sps = this.assembler.sps;
      const p = sps[1].toString(16).padStart(2, "0");
      const c = sps[2].toString(16).padStart(2, "0");
      const l = sps[3].toString(16).padStart(2, "0");
      return `avc1.${p}${c}${l}`;
    }
    return "avc1.640028"; // High Profile Level 4.0 fallback for BMW HD
  }

  _updateDebugBanner(extra) {
    const dbg = document.getElementById("debugOutput");
    if (!dbg) return;
    const isVisible = dbg.classList.contains("visible") || (window.showAdvancedDetails === true);
    if (!isVisible) {
      dbg.style.display = "none";
      return;
    }
    dbg.style.display = "block";
    const asm = this.assembler;
    const spsHex = asm && asm.sps ? Array.from(asm.sps.slice(0, 4)).map(b => b.toString(16).padStart(2, "0")).join("") : "none";
    const ppsHex = asm && asm.pps ? Array.from(asm.pps.slice(0, 4)).map(b => b.toString(16).padStart(2, "0")).join("") : "none";
    dbg.textContent = `Decoder: ${this.decoder ? this.decoder.state : 'null'} | Queue: ${this.decoder ? this.decoder.decodeQueueSize : 0} | FramesDecoded: ${this.decodedFrames.size} | AUs: ${this.accessUnits.length} | Codec: ${this._getCodecString()} | SPS: ${spsHex} PPS: ${ppsHex} | Err: ${window.lastWebCodecsError || 'none'} ${extra || ''}`;
  }

  _setState(state, message = '') {
    this.playbackState = state;
    if (this.onStateChange) this.onStateChange({state, message, time: this.currentTime, duration: this.duration, loaded: this.loadedByteOffset, total: this.totalBytes});
  }

  _fail(error) {
    this.pause(); this.loadError = error instanceof Error ? error : new Error(String(error));
    this._setState('error', this.loadError.message);
  }

  _initDecoder() {
    const epoch = ++this._decoderEpoch;
    this._pendingFrames = new Set();
    if (this.decoder && this.decoder.state !== 'closed') this.decoder.close();
    if (typeof VideoDecoder === 'undefined') return;
    const decoder = new VideoDecoder({
      output: frame => {
        const index = frame.timestamp;
        if (epoch !== this._decoderEpoch || index < this.currentAuIndex - 4) { if (epoch === this._decoderEpoch) this._pendingFrames.delete(index); frame.close(); return; }
        createImageBitmap(frame).then(bitmap => {
          if (epoch !== this._decoderEpoch) { bitmap.close(); return; }
          const old = this.decodedFrames.get(index); if (old) old.close();
          this.decodedFrames.set(index, bitmap);
          this._pendingFrames.delete(index);
          this._evictFrames();
          this._renderFrameAtTime(this.currentTime);
          if (this._hasFramesAt(this.currentTime)) this._setState(this.isPlaying ? 'playing' : 'paused');
        }).catch(e => { if (epoch === this._decoderEpoch) this._fail(e); }).finally(() => frame.close());
      },
      error: e => { if (epoch === this._decoderEpoch) this._fail(new Error('This recording could not be decoded. Retry or use the computer preview server. ' + e.message)); }
    });
    this.decoder = decoder;
    decoder.addEventListener('dequeue', () => {
      if (epoch !== this._decoderEpoch || this._decodeScheduled) return;
      this._decodeScheduled = true;
      setTimeout(() => { this._decodeScheduled = false; if (epoch === this._decoderEpoch) this._decodeAhead(); }, 0);
    });
    const config = {codec: this._getCodecString(), optimizeForLatency: true};
    if (this.assembler) config.description = RtpH264Assembler.makeAvcC(this.assembler.sps, this.assembler.pps);
    decoder.configure(config);
  }

  cancelLoad() {
    ++this._clipEpoch; ++this._decoderEpoch;
    this.pause();
    this._activeStreamAbort?.abort();
    if (this.decoder && this.decoder.state !== 'closed') this.decoder.close();
    this.decoder = null;
    if (this._nativeVideo) { this._nativeVideo.pause(); this._nativeVideo.removeAttribute('src'); this._nativeVideo.load(); this._nativeVideo.remove(); this._nativeVideo = null; }
    this._clearFrameCache(); this.lastFrFrame = null; this.lastLrFrame = null;
    this.manifest = null; this.parser = null; this.nativeInfo = null;
  }

  async loadClip(manifestUrl, bvrUrl, clipId = null) {
    this.cancelLoad();
    const epoch = this._clipEpoch;
    const controller = new AbortController(); this._activeStreamAbort = controller;
    const signal = controller.signal;
    this.loadError = null; this.streamComplete = false;
    this.currentTime = 0; this.currentAuIndex = 0; this.nextDecodeIdx = 0;
    this.loadedByteOffset = 0; this.totalBytes = 0; this.accessUnits = [];
    this.bvrUrl = bvrUrl;
    this._setState('loading', 'Reading recording information…');
    const response = await bvFetch(manifestUrl, {signal});
    if (!response.ok) throw new Error('Recording information unavailable: HTTP ' + response.status);
    const manifest = await response.json();
    if (signal.aborted || epoch !== this._clipEpoch) throw new DOMException('Cancelled', 'AbortError');
    this.manifest = manifest; this.duration = manifest.durationSeconds || 0;
    this.activeClipId = clipId || (manifest && manifest.id) || null;
    this.cameraMapping = this._loadCameraMapping(this.activeClipId);
    this._updateScrubber();
    if (this.nativeAvailable) return this._loadNative(manifest, epoch, signal);
    if (typeof VideoDecoder === 'undefined') throw new Error('Video playback needs HTTPS on this browser. Open the HTTPS address, or use the computer LAN test server for native playback.');
    this.assembler = new RtpH264Assembler({startMonotonicUs: manifest.startMonotonicUs, recoveryInfo: manifest.recoveryInfo});
    const assembler = this.assembler;
    let released=0;
    const parser = new StreamingBvrParser({onVideoRecord: r => {
      assembler.process([r], parser.cameraPairEvents);
      while(released<assembler.accessUnits.length) assembler.accessUnits[released++].data=null;
    }});
    this.parser = parser; this.accessUnits = assembler.accessUnits;
    const stream = await bvFetch(bvrUrl, {signal});
    if (!stream.ok) throw new Error('Recording stream unavailable: HTTP ' + stream.status);
    this.totalBytes = Number(stream.headers.get('Content-Length')) || manifest.bytes || 0;
    this.streamPromise = (async () => {
      const reader = stream.body.getReader();
      try {
        while (true) {
          const {done,value} = await reader.read();
          if (signal.aborted || epoch !== this._clipEpoch) return;
          if (done) break;
          this.loadedByteOffset += value.byteLength; parser.append(value);
          if (!this.decoder && this.accessUnits.length >= 2) this._initDecoder();
          this._decodeAhead();
          if (this.playbackState === 'loading') this._setState('loading', 'Preparing the first camera frames…');
          await new Promise(resolve => setTimeout(resolve, 0));
        }
        assembler.flush(parser.cameraPairEvents);
        while(released<assembler.accessUnits.length) assembler.accessUnits[released++].data=null;
        this.streamComplete = true;
        if (!this.decoder && this.accessUnits.length) this._initDecoder();
        this._decodeAhead();
        if (!this.accessUnits.length) throw new Error('No usable video frames in this recording.');
        if (this.liveMap) this.liveMap.setTrack(parser.getRouteSeries(manifest.startMonotonicUs));
      } catch (e) { if (!signal.aborted && epoch === this._clipEpoch) this._fail(e); }
      finally { reader.releaseLock(); }
    })();
    const start = performance.now();
    while (!this._hasFramesAt(0)) {
      if (signal.aborted || epoch !== this._clipEpoch) throw new DOMException('Cancelled','AbortError');
      if (this.loadError) throw this.loadError;
      if (performance.now() - start > 45000) throw new Error('The first video frame is taking too long. Check the connection and retry.');
      await new Promise(resolve => setTimeout(resolve, 25));
    }
    this._renderFrameAtTime(0); this._updateTelemetryHud(); this._setState('paused');
  }

  async _loadNative(manifest, epoch, signal) {
    this._setState('loading', 'Preparing a phone-friendly video. The first open may take a moment…');
    const response = await bvFetch(`/api/v1/preview/${encodeURIComponent(manifest.id)}`, {signal});
    if (!response.ok) { const body = await response.json().catch(() => ({})); throw new Error(body.error || 'Native preview unavailable'); }
    const info = await response.json();
    if (signal.aborted || epoch !== this._clipEpoch) throw new DOMException('Cancelled','AbortError');
    this.nativeInfo = info;
    this.parser = new StreamingBvrParser({}); this.parser.telemetryRecords = info.telemetry || [];
    this.assembler = null; this.accessUnits = [];
    const video = document.createElement('video'); this._nativeVideo = video;
    video.muted = true; video.playsInline = true; video.preload = 'auto';
    video.setAttribute('playsinline',''); video.setAttribute('aria-hidden','true');
    video.style.cssText = 'position:fixed;width:1px;height:1px;opacity:0.001;pointer-events:none;bottom:0;left:0;';
    document.body.appendChild(video);
    this._nativePairs = [0,1].map(() => { const c = document.createElement('canvas'); c.width=1280; c.height=480; return c; });
    const live = () => epoch === this._clipEpoch && !signal.aborted;
    video.addEventListener('waiting', () => { if (live()) this._setState('buffering','Buffering video…'); });
    video.addEventListener('seeking', () => { if (live()) this._setState('buffering','Seeking…'); });
    video.addEventListener('seeked', () => { if (live()) { this.currentTime = video.currentTime; this._renderNativeFrame(); this._updateScrubber(); this._updateTelemetryHud(); this._setState(this.isPlaying ? 'playing' : 'paused'); } });
    video.addEventListener('playing', () => { if (live()) this._setState('playing'); });
    video.addEventListener('ended', () => { if (live()) { this.currentTime=this.duration; this.pause(); this._updateScrubber(); this._setState('ended'); this.onEnded?.(); } });
    video.addEventListener('error', () => { if (live()) this._fail(new Error('The browser could not play this video preview. Please retry.')); });
    await new Promise((resolve,reject) => {
      const timer = setTimeout(() => finish(new Error('Video preview timed out.')), 45000);
      const aborted = () => finish(new DOMException('Cancelled','AbortError'));
      const ready = () => finish(); const failed = () => finish(new Error('Video preview could not be loaded.'));
      const finish = error => { clearTimeout(timer); signal.removeEventListener('abort',aborted); video.removeEventListener('loadeddata',ready); video.removeEventListener('error',failed); error ? reject(error) : resolve(); };
      signal.addEventListener('abort',aborted,{once:true}); video.addEventListener('loadeddata',ready,{once:true}); video.addEventListener('error',failed,{once:true}); video.src=info.mediaUrl; video.load();
    });
    if (!live()) throw new DOMException('Cancelled','AbortError');
    this.duration = Number.isFinite(video.duration) ? video.duration : this.duration;
    this.streamComplete = true; this.loadedByteOffset = this.totalBytes = manifest.bytes || 0;
    if (this.liveMap) this.liveMap.setTrack(this.parser.getRouteSeries(manifest.startMonotonicUs));
    this._renderNativeFrame(); this._updateScrubber(); this._updateTelemetryHud(); this._setState('paused');
  }

  _renderNativeFrame() {
    const v=this._nativeVideo; if (!v || v.readyState < 2) return false;
    this._nativePairs.forEach((c,i) => c.getContext('2d').drawImage(v,0,i*480,1280,480,0,0,1280,480));
    const p0Fr=this.cameraMapping.phase0 === 'frontRear';
    this.lastFrFrame=this._nativePairs[p0Fr?0:1]; this.lastLrFrame=this._nativePairs[p0Fr?1:0];
    this._drawToCanvas(this.lastFrFrame,this.lastLrFrame); this.liveMap?.setTime(this.currentTime); return true;
  }

  _clearFrameCache() { this.decodedFrames.forEach(b => { try { b.close(); } catch (_) {} }); this.decodedFrames.clear(); }
  _evictFrames() {
    for (const [i,b] of this.decodedFrames) {
      if (i < this.currentAuIndex-6 || i > this.currentAuIndex+32) {
        if (b === this.lastFrFrame) this.lastFrFrame=null;
        if (b === this.lastLrFrame) this.lastLrFrame=null;
        b.close(); this.decodedFrames.delete(i);
      }
    }
  }
  _indexAt(time) {
    let lo=0,hi=this.accessUnits.length-1,best=0;
    while(lo<=hi) { const mid=(lo+hi)>>1; if(this.accessUnits[mid].time<=time) {best=mid;lo=mid+1;} else hi=mid-1; } return best;
  }
  _hasFramesAt(time) {
    if (!this.accessUnits.length) return false;
    const i=this._indexAt(time);
    if (time > this.accessUnits[this.accessUnits.length-1].time + 0.08 && !this.streamComplete) return false;
    return this.decodedFrames.has(i) && this.decodedFrames.has(i > 0 ? i-1 : Math.min(1,this.accessUnits.length-1));
  }
  _resetDecoderForSeek(target) {
    this._clearFrameCache(); this.lastFrFrame=null; this.lastLrFrame=null;
    this._initDecoder();
    let start=Math.max(0,target-1); while(start>0 && !this.accessUnits[start].isKeyFrame) start--;
    this.nextDecodeIdx=start; this._decodeAhead();
  }
  _makeChunk(options) { return new EncodedVideoChunk(options); }
  _decodeAhead() {
    const decoder=this.decoder;
    if (!decoder || decoder.state !== 'configured' || this._nativeVideo) return;
    const end=Math.min(this.accessUnits.length,this.currentAuIndex+26);
    while(this.nextDecodeIdx<end && decoder.decodeQueueSize<8) {
      const au=this.accessUnits[this.nextDecodeIdx];
      if (!au?.avcc?.byteLength) {this.nextDecodeIdx++;continue;}
      try { this._pendingFrames?.add(au.index); decoder.decode(this._makeChunk({type:au.isKeyFrame?'key':'delta',timestamp:au.index,data:au.avcc})); this.nextDecodeIdx++; }
      catch(e) {this._fail(e);break;}
    }
    this._evictFrames();
  }
  async play({restartAtEnd=true} = {}) {
    if (this.isPlaying || !this.manifest || this.loadError) return;
    if (restartAtEnd && this.currentTime >= this.duration-0.05) this.seek(0);
    if (this._nativeVideo) {
      try { await this._nativeVideo.play(); } catch (_) { this._setState('paused','Ready. Tap Play to start video.'); return; }
    }
    this.isPlaying=true; this.lastFrameWallTime=performance.now();
    if(this.hud.playBtn) { this.hud.playBtn.innerHTML='<svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor"><path d="M6 4h4v16H6zm8 0h4v16h-4z"/></svg>'; this.hud.playBtn.setAttribute('aria-label','Pause'); }
    this._setState('playing'); this._tick();
  }
  pause() {
    this.isPlaying=false; this._nativeVideo?.pause();
    if(this.rafId) cancelAnimationFrame(this.rafId); this.rafId=null;
    if(this.hud.playBtn) {this.hud.playBtn.innerHTML='<svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor"><polygon points="5,3 19,12 5,21"/></svg>';this.hud.playBtn.setAttribute('aria-label','Play');}
    if(this.playbackState !== 'loading' && this.playbackState !== 'error') this._setState('paused');
  }
  togglePlay() { if(this.isPlaying) this.pause(); else this.play(); }
  seek(seconds) {
    this.currentTime=Math.max(0,Math.min(this.duration,Number(seconds)||0)); this.lastFrameWallTime=performance.now();
    if(this._nativeVideo) {this._nativeVideo.currentTime=this.currentTime; this._setState('buffering','Seeking…');}
    else if(this.accessUnits.length) {
      this.currentAuIndex=this._indexAt(this.currentTime);
      if(!this._hasFramesAt(this.currentTime)) {
        this._setState('buffering','Preparing this part of the recording…');
        const required=[this.currentAuIndex,Math.max(0,this.currentAuIndex-1)];
        const evicted=required.some(i => i<this.nextDecodeIdx && !this.decodedFrames.has(i) && !this._pendingFrames?.has(i));
        if(evicted) this._resetDecoderForSeek(this.currentAuIndex);
        else this._decodeAhead();
      }
      this._renderFrameAtTime(this.currentTime);
    }
    this._updateScrubber(); this._updateTelemetryHud();
  }
  async seekAndWait(seconds) {
    const clipEpoch=this._clipEpoch, seekEpoch=this._seekEpoch=(this._seekEpoch||0)+1;
    const initialPairTime=this._nativeVideo && Number.isFinite(this.nativeInfo?.firstCompleteFrameTime)?this.nativeInfo.firstCompleteFrameTime:0;
    this.seek(Math.max(Number(seconds)||0,initialPairTime));
    const target=this.currentTime, start=Date.now();
    while (true) {
      if(clipEpoch!==this._clipEpoch || seekEpoch!==this._seekEpoch) throw new DOMException('Cancelled','AbortError');
      if(this.loadError) throw this.loadError;
      if(!this._nativeVideo)this.currentAuIndex=this._indexAt(target);
      const ready=this._nativeVideo ? !this._nativeVideo.seeking && this._nativeVideo.readyState>=2 && Math.abs(this._nativeVideo.currentTime-target)<0.1 : this._hasFramesAt(target);
      if(ready && this._renderFrameAtTime(target)) {
        this._updateScrubber();this._updateTelemetryHud();
        this._setState(this.isPlaying?'playing':'paused');
        return;
      }
      if(Date.now()-start>45000) throw new Error('This part of the video could not be prepared. Please retry.');
      if(!this._nativeVideo)this._decodeAhead();
      await new Promise(resolve=>setTimeout(resolve,25));
    }
  }
  step(direction) {this.pause();this.seek(this.currentTime+direction/30);}
  setViewMode(mode) {this.viewMode=mode;this.sedanSelector?.setLayout(mode);this._renderFrameAtTime(this.currentTime);}
  setSpeedUnit(unit) {this.speedUnit=unit;this._updateTelemetryHud();}
  setSedanSelector(selector) {this.sedanSelector=selector;}
  setLiveMap(map) {this.liveMap=map;}
  _tick() {
    if(!this.isPlaying) return;
    const now=performance.now(),dt=Math.min(0.15,Math.max(0,(now-this.lastFrameWallTime)/1000)); this.lastFrameWallTime=now;
    if(this._nativeVideo) {this.currentTime=this._nativeVideo.currentTime;this._renderNativeFrame();}
    else {
      const candidate=Math.min(this.duration,this.currentTime+dt);
      this.currentAuIndex=this.accessUnits.length?this._indexAt(candidate):0; this._decodeAhead();
      if(this._hasFramesAt(candidate)) {this.currentTime=candidate;this._renderFrameAtTime(candidate);this._setState('playing');}
      else this._setState('buffering','Buffering camera frames…');
      if(this.currentTime>=this.duration) {this.pause();this._updateScrubber();this._setState('ended');this.onEnded?.();return;}
    }
    this._updateScrubber(); this._updateTelemetryHud(); this.rafId=requestAnimationFrame(()=>this._tick());
  }
  _renderFrameAtTime(time) {
    if(this._nativeVideo) return this._renderNativeFrame();
    if(!this.accessUnits.length) return false;
    const index=this._indexAt(time);
    let b0=null, b1=null;
    for (let i = index; i >= Math.max(0, index - 12); i--) {
      const u = this.accessUnits[i];
      const uPhase = (u && u.phase !== undefined) ? u.phase : (i % 2);
      if (uPhase === 0 && !b0) b0 = this.decodedFrames.get(u.index);
      if (uPhase === 1 && !b1) b1 = this.decodedFrames.get(u.index);
      if (b0 && b1) break;
    }
    if (!b0) b0 = this.decodedFrames.get(index % 2 === 0 ? index : index - 1);
    if (!b1) b1 = this.decodedFrames.get(index % 2 === 1 ? index : Math.max(1, index - 1));
    const p0Fr=this.cameraMapping.phase0==='frontRear';
    if(b0) this[p0Fr?'lastFrFrame':'lastLrFrame']=b0;
    if(b1) this[p0Fr?'lastLrFrame':'lastFrFrame']=b1;
    if(!this.lastFrFrame && !this.lastLrFrame) return false;
    this._drawToCanvas(this.lastFrFrame,this.lastLrFrame); this.liveMap?.setTime(time); return true;
  }

  _drawToCanvas(frBmp, lrBmp) {
    const cw = this.canvas.width;
    const ch = this.canvas.height;
    const ctx = this.ctx;

    ctx.fillStyle = "#0a0c10";
    ctx.fillRect(0, 0, cw, ch);

    try {
      // Apply half-swapping if user inverted halves in camera identity
      const flip = this.cameraMapping.flipHalves;
      const h1x = flip ? 640 : 0;
      const h2x = flip ? 0 : 640;

      if (this.viewMode === "quad") {
        const qCtx = this.quadCtx;
        qCtx.fillStyle = "#0a0c10";
        qCtx.fillRect(0, 0, 1280, 960);
        if (frBmp) {
          try {
            qCtx.drawImage(frBmp, h1x, 0, 640, 480, 0, 0, 640, 480);
            qCtx.drawImage(frBmp, h2x, 0, 640, 480, 640, 0, 640, 480);
          } catch (e1) {
            console.warn("Draw frBmp err:", e1);
          }
        }
        if (lrBmp) {
          try {
            qCtx.drawImage(lrBmp, h1x, 0, 640, 480, 0, 480, 640, 480);
            qCtx.drawImage(lrBmp, h2x, 0, 640, 480, 640, 480, 640, 480);
          } catch (e2) {
            console.warn("Draw lrBmp err:", e2);
          }
        }

        this._drawQuadLabels(qCtx);
        ctx.drawImage(this.quadCanvas, 0, 0, cw, ch);

      } else if (this.viewMode === "source") {
        if (frBmp && lrBmp) {
          ctx.drawImage(frBmp, 0, 0, 1280, 480, 0, 0, cw, ch / 2);
          ctx.drawImage(lrBmp, 0, 0, 1280, 480, 0, ch / 2, cw, ch / 2);
          ctx.strokeStyle = "rgba(255, 255, 255, 0.2)";
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(0, ch / 2);
          ctx.lineTo(cw, ch / 2);
          ctx.stroke();
        } else if (frBmp) {
          ctx.drawImage(frBmp, 0, 0, 1280, 480, 0, 0, cw, ch);
        } else if (lrBmp) {
          ctx.drawImage(lrBmp, 0, 0, 1280, 480, 0, 0, cw, ch);
        }
        this._drawSingleBadge(ctx, "SOURCE · RAW ACCESS UNITS", cw, ch);

      } else if (this.viewMode === "front") {
        if (frBmp) {
          ctx.drawImage(frBmp, h1x, 0, 640, 480, 0, 0, cw, ch);
        }
        this._drawSingleBadge(ctx, "FRONT CAMERA", cw, ch);

      } else if (this.viewMode === "rear") {
        if (frBmp) {
          ctx.drawImage(frBmp, h2x, 0, 640, 480, 0, 0, cw, ch);
        }
        this._drawSingleBadge(ctx, "REAR CAMERA", cw, ch);

      } else if (this.viewMode === "left") {
        if (lrBmp) {
          ctx.drawImage(lrBmp, h1x, 0, 640, 480, 0, 0, cw, ch);
        }
        this._drawSingleBadge(ctx, "LEFT SIDE CAMERA", cw, ch);

      } else if (this.viewMode === "right") {
        if (lrBmp) {
          ctx.drawImage(lrBmp, h2x, 0, 640, 480, 0, 0, cw, ch);
        }
        this._drawSingleBadge(ctx, "RIGHT SIDE CAMERA", cw, ch);
      }
    } catch (drawErr) {
      console.error("Canvas draw error:", drawErr);
      window.lastWebCodecsError = "Draw error: " + (drawErr ? drawErr.message : String(drawErr));
      this._updateDebugBanner();
    }
  }

  /**
   * Helper for Camera Identity dialog: returns current raw source frame
   */
  getCurrentRawFrame(phase = 0) {
    if (this._nativeVideo) {
      const idx = phase === 1 ? 1 : 0;
      const bitmap = (this._nativePairs && this._nativePairs[idx]) || this.lastFrFrame || this.lastLrFrame;
      return {
        bitmap: bitmap,
        auIndex: idx,
        time: this.currentTime,
        rtpTimestamp: "native",
        ssrc: "native",
        isPhase0: idx === 0
      };
    }
    if (!this.accessUnits || this.accessUnits.length === 0) return null;
    const targetIdx = (phase === 1) ? 1 : 0;
    const au = (this.accessUnits.length > targetIdx) ? this.accessUnits[targetIdx] : (this.accessUnits[this.currentAuIndex] || this.accessUnits[0]);
    const bitmap = this.decodedFrames.get(au.index) || (targetIdx === 0 ? this.lastFrFrame : this.lastLrFrame) || this.lastFrFrame || this.lastLrFrame;
    return {
      bitmap: bitmap,
      auIndex: au.index,
      time: au.time,
      rtpTimestamp: au.rtpTimestamp,
      ssrc: au.ssrc,
      isPhase0: targetIdx === 0
    };
  }

  /**
   * Helper for Export Preview: returns mid-recording camera frames and telemetry
   */
  getMidRecordingFrames() {
    const midTime = (this.duration || 0) / 2;
    let telem = null;
    if (this.parser && this.manifest?.startMonotonicUs != null) {
      telem = this.parser.getTelemetryAtTime(midTime, this.manifest.startMonotonicUs);
    }
    let fr = this.lastFrFrame;
    let lr = this.lastLrFrame;

    if (this.accessUnits?.length && this.decodedFrames) {
      const idx = this._indexAt(midTime);
      const even = idx % 2 === 0 ? idx : idx - 1;
      const odd = idx % 2 === 1 ? idx : Math.max(1, idx - 1);
      const b0 = this.decodedFrames.get(even);
      const b1 = this.decodedFrames.get(odd);
      const p0Fr = this.cameraMapping.phase0 === 'frontRear';
      if (b0) { if (p0Fr) fr = b0; else lr = b0; }
      if (b1) { if (p0Fr) lr = b1; else fr = b1; }
    } else if (this._nativePairs) {
      const p0Fr = this.cameraMapping.phase0 === 'frontRear';
      fr = this._nativePairs[p0Fr ? 0 : 1] || fr;
      lr = this._nativePairs[p0Fr ? 1 : 0] || lr;
    }

    if (telem && telem.speedLimit == null && this.currentSpeedLimit) {
      telem.speedLimit = this.currentSpeedLimit.limit;
      telem.speedLimitUnit = this.currentSpeedLimit.unit;
    }

    return {
      fr: fr,
      lr: lr,
      time: midTime,
      telemetry: telem
    };
  }

  _drawSingleBadge(ctx, label, cw, ch) {
    ctx.save();
    ctx.font = "bold 14px -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif";
    const textWidth = ctx.measureText(label).width;
    const padX = 14;
    const badgeW = textWidth + padX * 2;
    const badgeH = 30;
    const x = 16;
    const y = 16;

    ctx.fillStyle = "rgba(10, 12, 16, 0.78)";
    ctx.beginPath();
    ctx.roundRect(x, y, badgeW, badgeH, 6);
    ctx.fill();
    ctx.strokeStyle = "rgba(255, 255, 255, 0.18)";
    ctx.lineWidth = 1;
    ctx.stroke();

    ctx.fillStyle = "#ffffff";
    ctx.fillText(label, x + padX, y + 20);
    ctx.restore();
  }

  _drawQuadLabels(qCtx) {
    qCtx.save();
    qCtx.font = "bold 18px -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif";
    
    const drawBadge = (text, x, y) => {
      qCtx.fillStyle = "rgba(10, 12, 16, 0.75)";
      qCtx.beginPath();
      qCtx.roundRect(x, y, 90, 28, 6);
      qCtx.fill();
      qCtx.strokeStyle = "rgba(255, 255, 255, 0.15)";
      qCtx.lineWidth = 1;
      qCtx.stroke();
      qCtx.fillStyle = "#ffffff";
      qCtx.fillText(text, x + 14, y + 20);
    };

    drawBadge("FRONT", 16, 16);
    drawBadge("REAR", 656, 16);
    drawBadge("LEFT", 16, 496);
    drawBadge("RIGHT", 656, 496);

    // Subtle divider lines
    qCtx.strokeStyle = "rgba(255, 255, 255, 0.12)";
    qCtx.lineWidth = 2;
    qCtx.beginPath();
    qCtx.moveTo(640, 0);
    qCtx.lineTo(640, 960);
    qCtx.moveTo(0, 480);
    qCtx.lineTo(1280, 480);
    qCtx.stroke();

    qCtx.restore();
  }

  _updateScrubber() {
    this.onTimeUpdate?.(this.currentTime);
    if (this.hud.scrubber) {
      this.hud.scrubber.value = this.currentTime;
      this.hud.scrubber.max = this.duration;
    }
    if (this.hud.timeDisplay) {
      const curStr = this._formatTime(this.currentTime);
      const durStr = this._formatTime(this.duration);
      this.hud.timeDisplay.textContent = `${curStr} / ${durStr}`;
    }
  }

  _updateTelemetryHud() {
    if (!this.parser) return;
    const telem = this.parser.getTelemetryAtTime(this.currentTime, this.manifest ? this.manifest.startMonotonicUs : 0);

    // Speed display
    if (this.hud.speedValue && this.hud.speedUnit) {
      const speed = this.speedUnit === "mph" ? telem.speedMph : telem.speedKph;
      this.hud.speedValue.textContent = this.parser.telemetryRecords.length ? speed : "—";
      this.hud.speedUnit.textContent = this.speedUnit === "mph" ? "MPH" : "KM/H";
    }

    // Speed limit badge
    if (this.hud.speedLimit) {
      if (telem.latitude != null && telem.longitude != null && !telem.speedLimit) {
        this._resolveSpeedLimit(telem.latitude, telem.longitude);
      }
      let limitVal = telem.speedLimit;
      let limitUnit = telem.speedLimitUnit || "mph";
      if (limitVal == null && this.currentSpeedLimit) {
        limitVal = this.currentSpeedLimit.limit;
        limitUnit = this.currentSpeedLimit.unit || "mph";
      }
      if (limitVal != null) {
        let displayLimit = limitVal;
        if (this.speedUnit === "km/h" && limitUnit === "mph") {
          displayLimit = Math.round(limitVal * 1.60934);
        } else if (this.speedUnit === "mph" && limitUnit === "km/h") {
          displayLimit = Math.round(limitVal * 0.621371);
        }
        this.hud.speedLimit.textContent = displayLimit;
      } else {
        this.hud.speedLimit.textContent = "—";
      }
    }

    // Option 3 Brake Pedal Animation
    if (this.hud.brakePedal) {
      const brakeEl = this.hud.brakePedal;
      if (telem.brakePressed) {
        brakeEl.classList.add("pedal-active-brake");
      } else {
        brakeEl.classList.remove("pedal-active-brake");
      }
    }

    // Option 3 Accelerator Pedal Animation
    if (this.hud.gasPedal) {
      const gasEl = this.hud.gasPedal;
      if (telem.gasPressed || telem.acceleratorPercent > 5) {
        gasEl.classList.add("pedal-active-gas");
        const gasRibs = gasEl.querySelectorAll(".gas-rib");
        gasRibs.forEach(rib => rib.style.stroke = "#38D47A");
      } else {
        gasEl.classList.remove("pedal-active-gas");
        const gasRibs = gasEl.querySelectorAll(".gas-rib");
        gasRibs.forEach(rib => rib.style.stroke = "rgba(140, 150, 175, 0.6)");
      }
    }

    // Steering Wheel Rotation
    if (this.hud.wheelFace) {
      const angle = telem.steeringAngleDeg || 0;
      this.hud.wheelFace.style.transform = `rotate(${-angle}deg)`;
      if (this.hud.wheelAngleVal) {
        this.hud.wheelAngleVal.textContent = `${Math.round(angle)}°`;
      }
    }

    // Blinkers / Indicators
    if (this.hud.blinkerLeft && this.hud.blinkerRight) {
      const ind = String(telem.indicator || telem.blinker || "off").toLowerCase();
      const isLeft = ind === "left" || ind === "hazard" || ind === "both" || ind.includes("links") || ind === "l";
      const isRight = ind === "right" || ind === "hazard" || ind === "both" || ind.includes("rechts") || ind === "r";

      if (isLeft) {
        this.hud.blinkerLeft.classList.add("blinker-active");
      } else {
        this.hud.blinkerLeft.classList.remove("blinker-active");
      }
      if (isRight) {
        this.hud.blinkerRight.classList.add("blinker-active");
      } else {
        this.hud.blinkerRight.classList.remove("blinker-active");
      }
    }
  }

  _resolveSpeedLimit(lat, lon) {
    if (lat == null || lon == null) return;
    const key = `${Number(lat).toFixed(3)},${Number(lon).toFixed(3)}`;
    if (this._speedLimitCache.has(key)) {
      this.currentSpeedLimit = this._speedLimitCache.get(key);
      return;
    }
    if (this._lastSpeedLimitLookupCoord === key) return;
    this._lastSpeedLimitLookupCoord = key;
    bvFetch(`/api/v1/speed-limit?lat=${lat}&lon=${lon}`)
      .then(r => r.ok ? r.json() : null)
      .then(data => {
        if (data && data.limit != null) {
          const limitObj = { limit: data.limit, unit: data.unit || "mph" };
          this._speedLimitCache.set(key, limitObj);
          this.currentSpeedLimit = limitObj;
          this._updateTelemetryHud();
        }
      })
      .catch(() => {});
  }

  _formatTime(seconds) {
    const s = Math.floor(seconds);
    const m = Math.floor(s / 60);
    const rem = s % 60;
    return `${m.toString().padStart(2, "0")}:${rem.toString().padStart(2, "0")}`;
  }
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = { BimmerVisionPlayer };
}
