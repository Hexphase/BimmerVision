#!/usr/bin/env bash
set -euo pipefail
[ "$(uname -s)" = Linux ] && [ "$(id -u)" -eq 0 ] || { echo "Run on the enrolled Linux head unit as root." >&2; exit 1; }
systemctl disable --now bimmervision-service.service
systemctl enable --now masel-cameras-live.service
echo "Original camera companion restored. Restore the original v0.1.4 OAP tgz with the existing Store workflow."
