# BimmerVision capture format and API v1

This contract is shared by the Node 8 compatible car recorder and Swift Mac app.
All lengths are bytes; integers in the archive are unsigned little endian.
JSON times `atUs` refer to process-monotonic microseconds; a fresh process gets
a new random sessionId. Values stay below JavaScript's exact integer limit.

## Archive

File header, 16 bytes: ASCII `BVR1` at 0, u32 version=1 at 4,
u32 headerBytes=16 at 8, u32 reserved=0 at 12.

Record header, 24 bytes: ASCII `BVRR` at 0; u8 type at 4 (1=RTP, 2=JSON event);
u8 flags=0 at 5; u16 headerBytes=24 at 6; u32 payloadBytes at 8;
u64 atUs at 12; u32 IEEE CRC32 of payload at 20. CRC32 starts at 0xffffffff,
uses reflected polynomial 0xedb88320, and final XOR 0xffffffff.
Maximum payload: RTP 65,536 bytes, event 262,144 bytes. Reject zero-length records,
invalid flags/version/type, invalid lengths, bad CRC, and non-exact timestamps.
A truncated tail is recoverable up to the last complete valid record, explicitly
reported. Stop at corruption; never silently treat a damaged archive as complete.

RTP payloads retain the entire original packet including extensions and padding.
Parse RTP v2, CSRC, extension, padding, SSRC, seq, timestamp, marker; depacketize
H.264 single NAL/STAP-A/FU-A with an 8 MiB NAL and access-unit cap. Group access
units by SSRC/timestamp/marker, preserving packet decoding order and original
90 kHz presentation timestamp. Drop damaged access units, mark discontinuities,
and wait for valid parameter sets and an IDR before decoding after loss.
Do not infer camera identity from arrival order, decoded frame number, or brightness.

The car recorder keeps a bounded RAM queue (default 64 MiB, up to 96 MiB via
`hardware.json` `recording.queueLimitBytes`) ahead of batched USB writes. When
the queue is more than half full or drops occur, `storageWarning` tells the
driver to use a faster USB 3.0 drive. Overflow refuses RTP payloads and
increments `applicationDroppedPackets` with a `queue-overflow` discontinuity.
Only USB flash drives whose Linux link speed is at least 5000 Mbps (USB 3.0) are
accepted for recording. When the camera feed stops for about three seconds
(reverse, parking, or camera unavailable), the active segment ends with
`camera-unavailable` and recording resumes on a new segment when packets
return while continuous mode stays enabled. Phone transfer reads yield while
`queuedBytes` is non-zero so capture stays ahead of downloads.

JSON event examples:

```json
{"type":"start","id":"uuid","sessionId":"uuid","sequence":1,"clock":{"iso":"2026-11-09T23:00:00.000Z","source":"head-unit-system","verified":false,"utcOffsetMinutes":-360}}
{"type":"clock","iso":"2026-11-09T23:00:00.000Z","source":"head-unit-system","verified":false,"utcOffsetMinutes":-360}
{"type":"telemetry","fields":{"speed":{"value":32.5,"unit":"km/h","atUs":1234,"valid":true,"source":"BMW SOME/IP"}}}
{"type":"discontinuity","reason":"rtp-sequence-gap","packets":2}
{"type":"cameraPair","ssrc":1,"rtpTimestamp":90000,"pair":"frontRear","provenance":"verified"}
{"type":"end","reason":"segment"}
```

cameraPair is only allowed when supported by authoritative evidence or an explicit
manual review. No live identity adapter is verified in the backup. Missing mapping
means source view and unavailable named tiles. A Mac-local mapping JSON stores
explicit `{ssrc,rtpTimestamp,pair,provenance:"manual"}` entries. One review
names that alternating camera pair for the whole recording; it does not alter
the captured archive or imply automatic verification.
Telemetry fields: speed, brake, accelerator, blinker, latitude, longitude,
steeringAngleDeg. Each is a value with source/atUs/valid, optional unit.
Consumers expire live readings after 2 s unless a source-specific validity rule
is available. Unknown data must remain unknown. Clock anchors are separate from
media timing. UTC offset is taken from the actual clock provider, never fixed -6.

## USB bundle and catalog

USB root contains `BimmerVision/<id>/capture.bvr` and `manifest.json`.
Active directories use `<id>.partial`; only finalized UUID directory names are
listed/served. Extra files such as Mac mapping/provenance are allowlisted explicitly.
There are no arbitrary file paths in API calls. A `.trash` sibling enables safe
recoverable deletion. Reject symlinks at all components.

Manifest required fields:

```json
{"schemaVersion":1,"format":"bvr1","id":"uuid","sessionId":"uuid","sequence":1,"startedAt":"2026-11-09T23:00:00.000Z","clock":{"source":"head-unit-system","verified":false,"utcOffsetMinutes":-360},"startMonotonicUs":0,"endMonotonicUs":120000000,"durationSeconds":120,"bytes":100000,"packets":1000,"observedSequenceGaps":0,"applicationDroppedPackets":0,"stopReason":"segment","cameraMapping":"unverified","previousId":null,"requiresPrevious":false,"complete":true}
```

startedAt may be null, unknown fields are ignored, unavailable optional values are
null or absent. `clock.verified=false` must remain visible in the Mac library.
`bytes` is capture.bvr length. `requiresPrevious` means the segment's opening
footage needs its predecessor; a later IDR cannot make earlier footage independent.
Optional `recoveryInfo` describes later recovery without removing that dependency.
Delete must protect required predecessors of finalized and active segments,
including the interval between predecessor publication and successor creation.
Partial recovery publishes
complete=false and stopReason=recovered-tail, not a false successful recording.

The Mac resolves required sibling predecessors with bounded chain depth/bytes and
cycle, session, identity and ordering validation. Earlier footage supplies decoder
pre-roll; the selected clip's timeline and export still start at zero. Missing
dependencies are shown explicitly. Network import retrieves retained required
predecessors when available rather than silently omit opening pictures.

Observed RTP/queue-loss events are diagnostic summaries, not extra decoder reset
commands. Their physical archive position can differ from their `atUs`. Raw RTP
sequence information is authoritative for packet loss/reordering. True receiver
exit/watchdog boundaries apply at their recorded monotonic time, scoped to their
SSRC when supplied. Preview and export share those interruption boundaries and
derive freshness from observed cadence; a fixed250ms expiry does not distinguish
a valid slow source from an interrupted one.

## Transfer API

Car Wi-Fi IPv4. Phone QR uses plain HTTP on port **8765** so Safari is not
prompted for the self-signed certificate:
`http://IP:8765/?code=12345678&fp=HEX`. Mac pairing uses **HTTPS on port 8766**
only (`https://IP:8766/`). The TLS certificate DER SHA256 fingerprint is still
displayed and included. The Mac pins that fingerprint. The phone session cookie
is `Secure` only on TLS.

JSON error response `{ "error": "human-readable" }`. No permissive CORS.
All data endpoints require `Authorization: Bearer TOKEN` or an HttpOnly
SameSite=Strict `bv_session` cookie. Session secrets are 32 random bytes as hex.
One active logical client; multiple sockets belonging to it are allowed.

- POST `/api/v1/pair`, body `{code:"12345678",clientId:"random-uuid"}`;
  returns `{token:"hex",csrf:"hex",apiVersion:1}`. Invalid=401, rate-limited=429,
  already paired=409. First successful claim consumes the code atomically.
- POST `/api/v1/logout`, authenticated, revokes credentials. New client requires
  new on-screen pairing cycle.
- GET `/api/v1/status` -> `{apiVersion:1,state:"Recording",drive:{total,used,free},clock:{...}}`.
- GET `/api/v1/recordings` -> `{apiVersion:1,recordings:[manifest,...]}`.
- GET `/api/v1/recordings/UUID/capture.bvr` and `/manifest.json`, authenticated,
  single byte range support, Content-Length, Accept-Ranges; invalid range=416.
- GET `/api/v1/recordings/UUID/download`, authenticated, streams a ustar tar
  containing `manifest.json`, `capture.bvr`, and `mapping.json` when present.
- DELETE `/api/v1/recordings/UUID`, authenticated; returns `{deleted:UUID}`;
  active, currently transferring, or depended-on recordings=409. Browser mutations
  need `X-BV-CSRF` and same-origin validation; bearer requests have no browser cookies.

The companion consumes RAM control/status files under
`/tmp/masel-cameras-<uid>/recorder-control.json` / `recorder-status.json`, owned
by the enrolled app uid, directory mode 0700. Control:
`{continuous:true,volume:"/media/ID",transfer:{visit:"uuid",visible:true,heartbeat:unixMs}}`.
Use companion-observed mtime and a monotonic 3 s lease; each new visit creates a
new code. App sends visible=false on focus loss/back/shutdown. Expiry destroys
all transfer sockets. Status includes state, drive, drives, activeId, error,
clock, metrics, transfer:{on,url,code,fingerprint,paired,error}.
