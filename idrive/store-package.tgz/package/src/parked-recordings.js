'use strict';
var fs=require('fs'),path=require('path'),crypto=require('crypto'),util=require('util');
var QRDisplay=require('./qr-display').QRDisplay;
var Controls=require('./remote-backup-ui').RemoteBackupUI.prototype;
var readDir=util.promisify(fs.readdir),stat=util.promisify(fs.lstat),real=util.promisify(fs.realpath);
var open=util.promisify(fs.open),read=util.promisify(fs.read),close=util.promisify(fs.close);
var video=require('./embedded-playback');
var PAGE=10, uuid=/^[a-f\d]{8}-(?:[a-f\d]{4}-){3}[a-f\d]{12}$/i;
function focused(e){return !!e&&[true,1,'1','true'].includes(e.value)}
function now(){var t=process.hrtime();return t[0]*1000000+Math.floor(t[1]/1000)}
function date(m,zone,liveOffset){
 const system=Date.parse(m.startedAt),clock=m.clock||{},anchors=clock.displayAnchors;
 let wall;
 if(Array.isArray(anchors)&&Number.isFinite(m.startMonotonicUs)){
   const a=anchors.find(v=>v&&Number.isSafeInteger(v.wallMs)&&Number.isSafeInteger(v.sampleUs));
   if(a)wall=a.wallMs+(m.startMonotonicUs-a.sampleUs)/1000;
 }
 if(!Number.isFinite(wall)){
   const stored=clock.utcOffsetMinutes;
   const offset=Number.isFinite(stored)&&stored!==0?stored:liveOffset;
   if(!zone&&!Number.isFinite(offset))return 'Dashboard time unavailable';
   wall=system+(zone?0:offset*60000);
 }else zone='UTC';
 if(!Number.isFinite(wall))return 'Recording date unavailable';
 return new Date(wall).toLocaleString('en-US',{timeZone:zone||'UTC',year:'numeric',month:'short',day:'numeric',hour:'numeric',minute:'2-digit'});
}
function time(s){s=Math.floor(Math.max(0,s));return Math.floor(s/60)+':'+('0'+s%60).slice(-2)}
async function list(root,active){
 if(await real(root)!==root)throw Error('USB folder unavailable');
 var clips=[];
 for(const id of await readDir(root)){
   if(!active())return [];
   if(!uuid.test(id))continue;
   var dir=path.join(root,id),fd;
   try{
     if(!(await stat(dir)).isDirectory())continue;
     fd=await open(path.join(dir,'manifest.json'),fs.constants.O_RDONLY|fs.constants.O_NOFOLLOW);
     var size=fs.fstatSync(fd).size;if(!size||size>1048576)continue;
     var body=Buffer.alloc(size),count=await read(fd,body,0,size,0);
     if(count.bytesRead!==size)continue;
     var m=JSON.parse(body.toString());
     if(m.id===id&&m.complete===true&&m.format==='bvr1'&&m.durationSeconds>0)
       clips.push({id:id,locked:m.locked===true,startedAt:m.startedAt,startMonotonicUs:m.startMonotonicUs,clock:m.clock,duration:m.durationSeconds});
   }catch(e){}finally{if(fd!==undefined){await close(fd);fd=undefined}}
 }
 return clips.sort((a,b)=>String(b.startedAt).localeCompare(String(a.startedAt))||a.id.localeCompare(b.id));
}
class ParkedRecordings{
 constructor(owner){
   this.owner=owner;this.cache={};this.text=Controls.text;this.rows=Controls.rows;this.property=Controls.property;
   this.display=new QRDisplay({verified:true,report:()=>{},file:''});this.active=false;
   this.display.onDial=(seq,knob,press)=>{
     if(!this.active||!this.clip||!this.owner.visible||this.owner.nativePage!=='PARKED_VIDEO')return;
     const last=this.dial;
     this.dial={seq:seq,knob:knob,press:press};
     if(last&&last.knob!==65535&&knob!==65535){
       const delta=((knob-last.knob+98304)%65536)-32768;
       if(delta&&Math.abs(delta)<=16){
         const st=this.owner.desk().parkedPlayback||{};
         const at=Number.isFinite(this.dialTarget)?this.dialTarget:st.key===this.key?st.position:this.seek;
         this.dialTarget=this.clamp((at||0)+delta*5);
         this.drawControls(this.dialTarget,true);
         clearTimeout(this.dialTimer);
         this.dialTimer=setTimeout(()=>{const target=this.dialTarget;this.dialTarget=null;
           if(this.active&&this.clip&&this.owner.visible&&this.owner.nativePage==='PARKED_VIDEO')this.play(target,this.paused);
         },180);
       }
     }
     if(press===1&&(!last||last.press!==1))this.toggle();
   };
   this.display.onTouch=(phase,x,y)=>{
     if(phase!==3||!this.active||!this.clip||!this.owner.visible||this.owner.nativePage!=='PARKED_VIDEO')return;
     const box=this.display.embed;
     if(!box||y>box.h)return;
     if(y<box.h-96){
       if((this.owner.desk().parkedPlayback||{}).quad!==true)return;
       const tile=require('./embedded-playback').tileAt(box,x,y);
       if(this.tile!==null)this.tile=null;
       else if(tile!==null)this.tile=tile;
       this.owner.render().catch(this.owner.report);return;
     }
     clearTimeout(this.dialTimer);
     this.dialTarget=null;
     if(x<135){
       this.toggle()
     }else if(x>=145)this.play(this.clamp((x-160)/(box.w-220)*this.clip.duration),this.paused);
     this.owner.render().catch(this.owner.report);
   };
 }
 bind(){
   const o=this.owner;
   const on=(name,event,cb)=>o.listen(o.component(name),event,e=>{
     if(this.active&&o.visible&&o.nativePage==='PARKED_RECORDINGS')Promise.resolve(cb(e)).catch(o.report);
   });
   for(let row=0;row<PAGE;row++)on('PLAY_CLIP_'+row,'focus',e=>{
     if(focused(e)&&!this.confirming){
       this.highlight=this.clips[this.page*PAGE+row]||null;
       return o.render();
     }
   });
   for(const name of ['PLAY_OLDER','PLAY_NEWER','PLAY_BACK'])on(name,'focus',e=>{
     if(focused(e)){this.highlight=null;return o.render()}
   });
   for(const prefix of ['LIST','VIDEO'])for(const action of ['LOCK','DELETE']){
     o.listen(o.component(prefix+'_'+action),'action',()=>{
       if(!this.active||!o.visible||this.pending||this.confirming)return;
       if(o.nativePage!==(prefix==='VIDEO'?'PARKED_VIDEO':'PARKED_RECORDINGS'))return;
       const target=this.clip||this.highlight;
       if(target)this.chooseAction(target,action).catch(o.report);
     });
   }
   on('CLIP_CANCEL','action',()=>{this.confirming=null;return o.render()});
   on('CLIP_CONFIRM','action',()=>{
     const target=this.confirming;
     if(target&&!this.pending){this.confirming=null;this.submit(target,'deleteClip');}
     return o.render();
   });
   for(let row=0;row<PAGE;row++)on('PLAY_CLIP_'+row,'action',()=>{if(this.clip||this.confirming||this.pending)return;const clip=this.clips[this.page*PAGE+row];if(clip&&(o.desk().parkedPlayback||{}).ready){this.note="";this.highlight=clip;this.clip=clip;this.play(0)}return o.render()});
   on('PLAY_OLDER','action',()=>{this.highlight=null;if((this.page+1)*PAGE<this.clips.length)this.page++;return o.render()});
   on('PLAY_NEWER','action',()=>{this.highlight=null;this.page=Math.max(0,this.page-1);return o.render()});
   on('PLAY_TOGGLE','action',()=>{if(!this.clip)return;const st=o.desk().parkedPlayback||{};
     if(st.ended||st.message)this.play(0);else{this.paused=!this.paused;this.beat()}return o.render()});
   on('PLAY_SEEK','changed',step=>{if(this.clip&&Number.isInteger(step)&&step>=0&&step<=100&&this.step!==step){
     this.play(Math.min(this.clip.duration-.1,step*this.clip.duration/100));return o.render()}});
   on('PLAY_BACK','action',()=>{if(!this.clip)return o.back();this.resetClip();this.beat();return o.render()});
   on('PARKED_RECORDINGS','visible',e=>{if(e&&!e.visible){this.leave();o.visible=false;o.nativePage=null;o.page='home';o.cache={}}});
 }
 async chooseAction(target,action){
   const o=this.owner;
   if(!this.clips.includes(target)||o.desk().volumeToken!==this.volume)return;
   if(action==='DELETE'&&target.locked)return;
   if(action==='DELETE')this.confirming=target;
   this.highlight=target;this.note='';
   if(this.clip){
     this.resetClip();this.beat();
     if(o.nativePage==='PARKED_VIDEO')await o.openNativePage('recordings','PARKED_RECORDINGS');
   }
   if(action==='LOCK')this.submit(target,'lockClip');
   await o.render();
 }
 submit(target,action){
   if(this.pending||!this.active||this.owner.desk().volumeToken!==this.volume)return;
   const command={id:crypto.randomBytes(16).toString('hex'),volumeToken:this.volume,clipId:target.id,action:action,locked:!target.locked};
   this.pending=command;this.note=action==='deleteClip'?'Deleting recording…':'Updating recording…';
   this.owner.update({driveCommand:command});
 }
 finishAction(result){
   const cmd=this.pending;
   if(!cmd||!result||result.id!==cmd.id)return;
   this.pending=null;
   if(!result.ok){this.note=result.message||'Recording could not be updated.';return}
   if(cmd.action==='deleteClip'){
     this.clips=this.clips.filter(c=>c.id!==cmd.clipId);
     this.page=Math.min(this.page,Math.max(0,Math.ceil(this.clips.length/PAGE)-1));
     this.highlight=null;this.note='Recording deleted.';
   }else{
     const clip=this.clips.find(c=>c.id===cmd.clipId);
     if(clip)clip.locked=cmd.locked;
     this.note=cmd.locked?'Recording locked.':'Recording unlocked.';
   }
 }
 resetClip(){clearTimeout(this.dialTimer);this.dialTarget=null;this.dial=null;this.fallback=false;this.tile=null;this.clip=null;this.key=null;this.paused=false;this.step=null;this.hide()}
 hide(){if(this.display.sock||this.display.loading)this.display.hideHead();this.display.boundFile=null;this.shown=null}
 leave(){if(!this.active)return;this.active=false;this.resetClip();this.owner.update({playback:null})}
 async enter(){
   this.leave();const o=this.owner,desk=o.desk();this.volume=desk.volumeToken;this.pending=null;this.confirming=null;this.highlight=null;this.clips=[];this.page=0;this.cache={};this.resetClip();
   await o.openNativePage('recordings','PARKED_RECORDINGS');this.active=true;this.loading=true;this.note='';
   this.beat();await o.render();const token=this.volume;
   try{if(desk.drive&&desk.drive.mount)this.clips=await list(path.join(desk.drive.mount,'BimmerVision'),()=>this.active&&this.volume===token)}
   catch(e){this.note='USB recordings unavailable.'}finally{this.loading=false}
   if(this.active)await o.render();
 }
 drawControls(position,seekFocus){
   video.redraw(this.display,position/this.clip.duration,this.paused,false,this.tile,seekFocus);
 }
 clamp(position){return Math.max(0,Math.min(this.clip.duration-.1,position))}
 toggle(){const st=this.owner.desk().parkedPlayback||{};
   if(st.ended&&st.key===this.key&&!Number.isFinite(this.dialTarget))this.play(0);
   else{this.paused=!this.paused;this.beat()}
   const seeking=Number.isFinite(this.dialTarget);
   this.drawControls(seeking?this.dialTarget:st.key===this.key?st.position||0:this.seek,seeking);
 }
 play(position,paused){this.seek=Math.max(0,position);this.paused=!!paused;this.key=crypto.randomBytes(12).toString('hex');this.beat()}
 beat(){
   if(!this.active)return;
   const desk=this.owner.desk(),age=now()-desk.heartbeatMonotonicUs,st=desk.parkedPlayback||{};
   if(this.volume!==desk.volumeToken||!desk.drive){this.resetClip();this.confirming=null;this.pending=null;this.highlight=null;this.clips=[];this.note='USB drive disconnected.'}
   if(this.clip&&(st.message||!(age>=0&&age<1800000)||desk.recordingEnabled!==false)){this.hide()}
   this.owner.update({playback:{volume:this.volume,id:this.clip&&this.clip.id,key:this.key,seek:this.seek||0,paused:this.paused,beat:now()}});
 }
 async render(){
   const desk=this.owner.desk(),st=desk.parkedPlayback||{},clip=this.clip;
   this.finishAction(desk.clipResult);
   const target=clip||this.highlight;
   const actionable=!!target&&!this.pending&&!this.confirming&&desk.recordingsAvailable===true&&this.volume===desk.volumeToken;
   const prefix=this.owner.nativePage==='PARKED_VIDEO'?'VIDEO':'LIST';
   await this.text(prefix+'_LOCK',target&&target.locked?'Unlock recording':'Lock recording');
   await this.property(prefix+'_LOCK','Enabled',actionable);
   await this.property(prefix+'_DELETE','Enabled',actionable&&!target.locked);
   await this.property('CLIP_CANCEL','Visible',!!this.confirming);
   await this.property('CLIP_CONFIRM','Visible',!!this.confirming);
   const names=['PLAY_OLDER','PLAY_NEWER','PLAY_TOGGLE','PLAY_SEEK','PLAY_STATUS','PLAY_BACK'];
   const message=this.confirming?("Delete "+date(this.confirming,this.owner.displayTimeZone,desk.dashboardOffsetMinutes)+" ("+time(this.confirming.duration)+")?"):this.note||(!desk.drive?'Connect a USB drive.':this.loading?'Loading recordings…':!clip?
     !st.ready?'Select Park and disable recording to play.':!this.clips.length?'No recordings on this drive.':'':st.message||'');
   const browsing=!this.confirming&&(!clip||(!this.fallback&&this.owner.nativePage==='PARKED_RECORDINGS'));
   const vis=[browsing&&(this.page+1)*PAGE<this.clips.length,browsing&&this.page>0,!!clip&&this.fallback,!!clip&&this.fallback,!!message,!this.confirming];
   for(let i=0;i<names.length;i++)await this.property(names[i],'Visible',vis[i]);
   await this.text('PLAY_TITLE',clip&&this.fallback?date(clip,this.owner.displayTimeZone,desk.dashboardOffsetMinutes):'Recordings');
   await this.text('PLAY_STATUS',message);await this.text('PLAY_BACK',clip&&this.fallback?'Recordings':'Back');
   for(let row=0;row<PAGE;row++){
     const item=browsing&&this.clips[this.page*PAGE+row],name='PLAY_CLIP_'+row;
     if(item)await this.text(name,date(item,this.owner.displayTimeZone,desk.dashboardOffsetMinutes)+'   ·   '+time(item.duration)+(item.locked?'   ·   Locked':''));
     await this.property(name,'Visible',!!item);
   }
   if(!clip){
     await this.text('PLAY_NEWER','Newer recordings');await this.text('PLAY_OLDER','Older recordings');return}
   const preview=Number.isFinite(this.dialTarget);
   const pos=preview?this.dialTarget:st.key===this.key?st.position||0:this.seek;
   await this.text('PLAY_TOGGLE',st.ended?'Replay':st.message?'Retry':this.paused?'Play':'Pause');
   const slider=this.owner.component('PLAY_SEEK'),step=Math.min(100,Math.round(pos*100/clip.duration));
   if(slider&&this.step!==step){this.step=step;await slider.setStepValue(step)}
   const elapsed=time(pos)+' / '+time(clip.duration);
   if(slider&&elapsed!==this.elapsed){this.elapsed=elapsed;await slider.setValue(0,'TextDescription',elapsed,'Text')}
   if(this.owner.nativePage==='PARKED_VIDEO'&&message){
     this.resetClip();this.beat();await this.owner.openNativePage('recordings','PARKED_RECORDINGS');this.note=message;return;
   }
   if(this.owner.nativePage==='PARKED_VIDEO'&&this.display.boundFile&&(st.key!==this.key||!st.file)&&!message){
     await this.text('VIDEO_TITLE','Seeking   '+elapsed);
     this.drawControls(pos,true);return;
   }
   if(!this.active||!this.clip||st.key!==this.key||!st.file||!/^\/dev\/shm\/mgu-video-bv-[0-9a-f]{24}\.frame$/.test(st.file))return;
   const epoch=this.key,age=now()-desk.heartbeatMonotonicUs;
   if(!(age>=0&&age<1800000)||desk.recordingEnabled!==false)return;
   try{
     await this.display.connect();
     if(!this.active||this.key!==epoch||!this.owner.visible)return;
     if(this.display.offerEmbed){
       if(this.owner.nativePage==='PARKED_RECORDINGS'){
         await this.owner.openNativePage('recordings','PARKED_VIDEO');
         if(!this.active||this.key!==epoch)return;
       }
       if(this.owner.nativePage!=='PARKED_VIDEO')return;
       if(!st.quad)this.tile=null;
       const hint=st.quad?(this.tile===null?'Tap a camera':'Tap for all cameras'):'';
       await this.text('VIDEO_TITLE',date(clip,this.owner.displayTimeZone,desk.dashboardOffsetMinutes)+'   '+elapsed+(hint?'   ·   '+hint:''));
       video.present(this.display,st.file,pos/clip.duration,this.paused,st.ended,this.tile,preview);
       return;
     }
     if((this.display.caps&272)!==272)throw Error('Renderer needs NV12 video support');
     this.fallback=true;const b=this.display.box,w=Math.floor(Math.min(b.w*.48,b.h*4/3)/2)*2,h=Math.floor(w*.75/2)*2;
     this.display.frameOverride={x:b.x+b.w-w-12,y:b.y+Math.floor((b.h-h)/2),w:w,h:h};
     this.display.file=st.file;this.display.layout();this.shown=st.file;
   }catch(e){this.resetClip();this.note='Video renderer unavailable.';this.beat()}
 }
}
module.exports={ParkedRecordings,date,list};
