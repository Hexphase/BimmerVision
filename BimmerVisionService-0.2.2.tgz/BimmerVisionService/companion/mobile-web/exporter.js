/**
 * BimmerVision Client-Side MP4 Exporter
 * Encodes selected camera view + telemetry HUD into standard MP4 on device.
 * Triggers native iOS Share Sheet ("Save Video" to Camera Roll) with zero car server CPU load.
 */
class ClipExporter {
  constructor(player) {
    this.player = player;
  }

  static assets = {
    wheel: null,
    wordmark: null,
    eye: null
  };

  /**
   * Export clip with options:
   * @param {Object} options
   * @param {string} options.view - "quad", "front", "rear", "left", "right", "source"
   * @param {Object} [options.overlays] - individual metadata toggle flags: { blinkers, speed, speedLimit, steering, brake, gas, time }
   * @param {boolean} [options.includeHud] - master telemetry switch (default true)
   * @param {string} options.speedUnit - "mph" or "km/h"
   * @param {string|number} options.duration - "full", 30, 15, 10
   * @param {function} options.onProgress - callback (progress 0..1, statusText)
   */
  async export(options = {}) {
    if (typeof VideoEncoder === 'undefined' || typeof Mp4Muxer === 'undefined') {
      if (typeof MediaRecorder !== 'undefined') {
        return this._exportWithMediaRecorder(options);
      }
      throw new Error('Customized video export needs HTTPS and a browser with video encoding support.');
    }
    const player = this.player;
    const view = options.view || 'quad';
    const speedUnit = options.speedUnit || player?.speedUnit || 'mph';
    const progress = options.onProgress || (() => {});

    // Overlays configuration
    const overlays = options.overlays != null ? options.overlays : (options.includeHud !== false ? {
      blinkers: true,
      speed: true,
      speedLimit: true,
      steering: true,
      brake: true,
      gas: true,
      time: true,
      map: true
    } : null);

    const includeMap = overlays ? (overlays.map !== undefined ? Boolean(overlays.map) : Boolean(options.includeMap)) : false;
    const hasTelemetryBar = overlays ? (overlays.includeHud !== false && (
      overlays.blinkers !== false ||
      overlays.speed !== false ||
      overlays.speedLimit !== false ||
      overlays.steering !== false ||
      overlays.brake !== false ||
      overlays.gas !== false ||
      overlays.time !== false
    )) : false;

    const exportW = includeMap ? 1920 : 1280;
    const exportH = includeMap ? (hasTelemetryBar ? 1080 : 960) : (hasTelemetryBar ? 1040 : 960);

    if (player?.streamPromise && !player.streamComplete) {
      progress(0.02, 'Waiting for the complete recording…');
      await player.streamPromise;
    }
    if (player?.loadError) throw player.loadError;
    if (!player?.manifest) throw new Error('Open a recording before exporting.');

    const manifest = player.manifest;
    const units = player.accessUnits;
    const parser = player.parser;
    const full = player.duration || 0;
    const requested = Number(options.duration);
    const duration = requested > 0 ? Math.min(requested, full) : full;
    const start = Math.max(0, full - duration);
    const fps = 30;
    const totalFrames = Math.max(1, Math.round(duration * fps));

    const canvas = document.createElement('canvas');
    canvas.width = exportW;
    canvas.height = exportH;

    const muxer = new Mp4Muxer.Muxer({
      target: new Mp4Muxer.ArrayBufferTarget(),
      video: { codec: 'avc', width: exportW, height: exportH },
      fastStart: 'in-memory'
    });

    let encodeError = null;
    let decodeError = null;
    let fallbackConfig = null;
    let encoder;
    let decoder;
    let submitted = 0;
    let flushed = false;
    const bitmaps = new Map();
    const pending = new Set();
    const mapping = { ...(player.cameraMapping || {}) };
    const p0Fr = mapping.phase0 !== 'leftRight';

    const nativeVideo = (!units?.length && player._nativeVideo) ? player._nativeVideo : null;
    const wasPaused = nativeVideo ? nativeVideo.paused : true;
    const origTime = nativeVideo ? nativeVideo.currentTime : 0;
    if (nativeVideo && !wasPaused) {
      nativeVideo.pause();
    }

    try {
      encoder = new VideoEncoder({
        output: (chunk, meta) => {
          try {
            let activeMeta = meta;
            if (!meta?.decoderConfig?.description) {
              fallbackConfig ||= this._extractDecoderConfigFromChunk(chunk);
              if (fallbackConfig) activeMeta = { ...meta, decoderConfig: fallbackConfig };
            }
            const bytes = new Uint8Array(chunk.byteLength);
            chunk.copyTo(bytes);
            muxer.addVideoChunkRaw(bytes, chunk.type, chunk.timestamp, chunk.duration ?? Math.round(1e6 / fps), activeMeta);
          } catch (e) {
            encodeError = e;
          }
        },
        error: e => {
          encodeError = e;
        }
      });
      encoder.configure({
        codec: 'avc1.420028',
        width: exportW,
        height: exportH,
        bitrate: exportW > 1280 ? 6000000 : 4500000,
        framerate: fps,
        avc: { format: 'avc' }
      });

      if (typeof VideoDecoder !== 'undefined' && units?.length && player.assembler) {
        decoder = new VideoDecoder({
          output: frame => {
            const job = createImageBitmap(frame).then(bitmap => {
              bitmaps.set(frame.timestamp, bitmap);
            }).catch(e => {
              decodeError = e;
            }).finally(() => {
              frame.close();
              pending.delete(job);
            });
            pending.add(job);
          },
          error: e => {
            decodeError = e;
          }
        });
        decoder.configure({
          codec: player._getCodecString ? player._getCodecString() : 'avc1.420028',
          description: RtpH264Assembler.makeAvcC(player.assembler.sps, player.assembler.pps),
          optimizeForLatency: true
        });
      }

      let targetIndex = 0;
      for (let frameIndex = 0; frameIndex < totalFrames; frameIndex++) {
        const time = start + frameIndex / fps;

        if (nativeVideo) {
          if (Math.abs(nativeVideo.currentTime - time) > 0.002) {
            await new Promise((resolve) => {
              let done = false;
              const finish = () => {
                if (!done) {
                  done = true;
                  clearTimeout(timer);
                  nativeVideo.removeEventListener('seeked', finish);
                  nativeVideo.removeEventListener('error', finish);
                  resolve();
                }
              };
              const timer = setTimeout(finish, 350);
              nativeVideo.addEventListener('seeked', finish, { once: true });
              nativeVideo.addEventListener('error', finish, { once: true });
              nativeVideo.currentTime = time;
            });
          }
          if (player._nativePairs && player._nativePairs.length >= 2) {
            player._nativePairs[0].getContext('2d').drawImage(nativeVideo, 0, 0, 1280, 480, 0, 0, 1280, 480);
            player._nativePairs[1].getContext('2d').drawImage(nativeVideo, 0, 480, 1280, 480, 0, 0, 1280, 480);
            const p0FrNative = mapping.phase0 === 'frontRear';
            player.lastFrFrame = player._nativePairs[p0FrNative ? 0 : 1];
            player.lastLrFrame = player._nativePairs[p0FrNative ? 1 : 0];
          }
        }

        while (targetIndex + 1 < (units?.length || 0) && units[targetIndex + 1].time <= time) {
          targetIndex++;
        }
        const p0 = targetIndex % 2 === 0 ? targetIndex : targetIndex - 1;
        const p1 = targetIndex % 2 === 1 ? targetIndex : Math.max(1, targetIndex - 1);

        if (decoder) {
          const ahead = Math.min(units.length, targetIndex + 16);
          const began = performance.now();
          while (!bitmaps.has(p0) || !bitmaps.has(p1)) {
            if (decodeError) throw new Error('The source recording could not be decoded for export: ' + decodeError.message);
            while (submitted < ahead && decoder.decodeQueueSize < 8) {
              const au = units[submitted++];
              decoder.decode(new EncodedVideoChunk({ type: au.isKeyFrame ? 'key' : 'delta', timestamp: au.index, data: au.avcc }));
            }
            if (submitted === units.length && !flushed) {
              flushed = true;
              await decoder.flush();
              await Promise.all([...pending]);
            }
            if (performance.now() - began > 15000) throw new Error('Timed out waiting for source frames. No incomplete export was saved.');
            await new Promise(r => setTimeout(r, 0));
          }
        }

        const b0 = bitmaps.get(p0) || player.decodedFrames?.get(p0);
        const b1 = bitmaps.get(p1) || player.decodedFrames?.get(p1);
        if (b0) {
          if (p0Fr) player.lastFrFrame = b0;
          else player.lastLrFrame = b0;
        }
        if (b1) {
          if (p0Fr) player.lastLrFrame = b1;
          else player.lastFrFrame = b1;
        }
        const fr = player.lastFrFrame;
        const lr = player.lastLrFrame;
        if (!fr && !lr) throw new Error('No camera image is available for export.');

        this.renderFrame(canvas, {
          view: view,
          overlays: overlays,
          speedUnit: speedUnit,
          time: time,
          fr: fr,
          lr: lr,
          telemetry: parser ? parser.getTelemetryAtTime(time, manifest.startMonotonicUs) : null,
          mapping: mapping,
          manifest: manifest,
          map: player?.liveMap
        });

        const frame = new VideoFrame(canvas, { timestamp: Math.round(frameIndex * 1e6 / fps), duration: Math.round(1e6 / fps) });
        try {
          encoder.encode(frame, { keyFrame: frameIndex % (fps * 2) === 0 });
        } finally {
          frame.close();
        }

        while (encoder.encodeQueueSize > 4) {
          if (encodeError) throw encodeError;
          await new Promise(r => setTimeout(r, 4));
        }
        if (encodeError) throw encodeError;

        for (const [index, bitmap] of bitmaps) {
          if (index < targetIndex - 4) {
            bitmap.close();
            bitmaps.delete(index);
          }
        }
        if (frameIndex % 4 === 0) await new Promise(r => setTimeout(r, 0));
        progress(0.1 + 0.8 * (frameIndex + 1) / totalFrames, `Rendering video · ${Math.round(100 * (frameIndex + 1) / totalFrames)}%`);
      }

      progress(0.94, 'Finalizing M4V video…');
      await encoder.flush();
      if (encodeError) throw encodeError;
      muxer.finalize();
      progress(1, 'Ready to save');
      return {
        buffer: muxer.target.buffer,
        fileName: `BimmerVision-${manifest.id.slice(0, 8)}-${view}${requested > 0 ? '-' + requested + 's' : ''}.m4v`,
        totalFrames,
        duration
      };
    } finally {
      if (nativeVideo) {
        try {
          nativeVideo.currentTime = origTime;
          if (typeof player._renderNativeFrame === 'function') {
            player._renderNativeFrame();
          }
          if (typeof player._updateTelemetryHud === 'function') {
            player._updateTelemetryHud();
          }
          if (!wasPaused) {
            nativeVideo.play().catch(() => {});
          }
        } catch (_) {}
      }
      if (decoder && decoder.state !== 'closed') decoder.close();
      if (encoder && encoder.state !== 'closed') encoder.close();
      await Promise.allSettled([...pending]);
      for (const bitmap of bitmaps.values()) bitmap.close();
    }
  }

  /**
   * MediaRecorder fallback for browsers/environments without WebCodecs VideoEncoder (e.g. HTTP on Android).
   */
  async _exportWithMediaRecorder(options = {}) {
    const player = this.player;
    const view = options.view || 'quad';
    const speedUnit = options.speedUnit || player?.speedUnit || 'mph';
    const progress = options.onProgress || (() => {});

    const overlays = options.overlays != null ? options.overlays : (options.includeHud !== false ? {
      blinkers: true,
      speed: true,
      speedLimit: true,
      steering: true,
      brake: true,
      gas: true,
      time: true,
      map: true
    } : null);

    const includeMap = overlays ? (overlays.map !== undefined ? Boolean(overlays.map) : Boolean(options.includeMap)) : false;
    const hasTelemetryBar = overlays ? (overlays.includeHud !== false && (
      overlays.blinkers !== false ||
      overlays.speed !== false ||
      overlays.speedLimit !== false ||
      overlays.steering !== false ||
      overlays.brake !== false ||
      overlays.gas !== false ||
      overlays.time !== false
    )) : false;

    const exportW = includeMap ? 1920 : 1280;
    const exportH = includeMap ? (hasTelemetryBar ? 1080 : 960) : (hasTelemetryBar ? 1040 : 960);

    if (player?.streamPromise && !player.streamComplete) {
      progress(0.02, 'Waiting for the complete recording…');
      await player.streamPromise;
    }
    if (player?.loadError) throw player.loadError;
    if (!player?.manifest) throw new Error('Open a recording before exporting.');

    const manifest = player.manifest;
    const parser = player.parser;
    const full = player.duration || 0;
    const requested = Number(options.duration);
    const duration = requested > 0 ? Math.min(requested, full) : full;
    const start = Math.max(0, full - duration);
    const fps = 30;
    const totalFrames = Math.max(1, Math.round(duration * fps));

    const canvas = document.createElement('canvas');
    canvas.width = exportW;
    canvas.height = exportH;

    // Render initial frame to setup canvas dimensions
    this.renderFrame(canvas, {
      view: view,
      overlays: overlays,
      speedUnit: speedUnit,
      time: start,
      fr: player.lastFrFrame,
      lr: player.lastLrFrame,
      telemetry: parser ? parser.getTelemetryAtTime(start, manifest.startMonotonicUs) : null,
      mapping: player.cameraMapping,
      manifest: manifest,
      map: player?.liveMap
    });

    const stream = canvas.captureStream ? canvas.captureStream(fps) : null;
    if (!stream) {
      throw new Error('Canvas stream capture is not supported by this browser.');
    }

    let mimeType = 'video/webm';
    if (typeof MediaRecorder.isTypeSupported === 'function') {
      if (MediaRecorder.isTypeSupported('video/mp4;codecs=avc1')) mimeType = 'video/mp4;codecs=avc1';
      else if (MediaRecorder.isTypeSupported('video/mp4')) mimeType = 'video/mp4';
      else if (MediaRecorder.isTypeSupported('video/webm;codecs=vp9')) mimeType = 'video/webm;codecs=vp9';
      else if (MediaRecorder.isTypeSupported('video/webm;codecs=vp8')) mimeType = 'video/webm;codecs=vp8';
    }

    const chunks = [];
    const recorder = new MediaRecorder(stream, { mimeType, videoBitsPerSecond: exportW > 1280 ? 6000000 : 4500000 });
    recorder.ondataavailable = e => { if (e.data && e.data.size > 0) chunks.push(e.data); };
    recorder.start(100);

    const nativeVideo = player._nativeVideo;
    const mapping = { ...(player.cameraMapping || {}) };
    const p0FrNative = mapping.phase0 === 'frontRear';
    const frameDelayMs = 1000 / fps;

    let playedSmoothly = false;
    if (nativeVideo && typeof nativeVideo.play === 'function' && typeof requestAnimationFrame === 'function') {
      try {
        if (Math.abs(nativeVideo.currentTime - start) > 0.05) {
          await new Promise((res) => {
            const onSeek = () => { nativeVideo.removeEventListener('seeked', onSeek); res(); };
            nativeVideo.addEventListener('seeked', onSeek, { once: true });
            setTimeout(onSeek, 400);
            nativeVideo.currentTime = start;
          });
        }
        await nativeVideo.play();
        playedSmoothly = true;
      } catch (_) {
        playedSmoothly = false;
      }
    }

    try {
      if (playedSmoothly) {
        const endTime = start + duration;
        const track = stream.getVideoTracks ? stream.getVideoTracks()[0] : null;
        let lastRenderedTime = -1;

        while (!nativeVideo.paused && !nativeVideo.ended && nativeVideo.currentTime < endTime) {
          const curTime = nativeVideo.currentTime;
          if (curTime !== lastRenderedTime) {
            lastRenderedTime = curTime;
            if (player._nativePairs && player._nativePairs.length >= 2) {
              player._nativePairs[0].getContext('2d').drawImage(nativeVideo, 0, 0, 1280, 480, 0, 0, 1280, 480);
              player._nativePairs[1].getContext('2d').drawImage(nativeVideo, 0, 480, 1280, 480, 0, 0, 1280, 480);
              player.lastFrFrame = player._nativePairs[p0FrNative ? 0 : 1];
              player.lastLrFrame = player._nativePairs[p0FrNative ? 1 : 0];
            }

            this.renderFrame(canvas, {
              view: view,
              overlays: overlays,
              speedUnit: speedUnit,
              time: curTime,
              fr: player.lastFrFrame,
              lr: player.lastLrFrame,
              telemetry: parser ? parser.getTelemetryAtTime(curTime, manifest.startMonotonicUs) : null,
              mapping: mapping,
              manifest: manifest,
              map: player?.liveMap
            });

            if (track && typeof track.requestFrame === 'function') {
              track.requestFrame();
            }

            const pct = Math.min(1, Math.max(0, (curTime - start) / duration));
            progress(0.1 + 0.85 * pct, `Recording video · ${Math.round(100 * pct)}%`);
          }

          await new Promise(r => {
            if (typeof nativeVideo.requestVideoFrameCallback === 'function') {
              nativeVideo.requestVideoFrameCallback(r);
            } else if (typeof requestAnimationFrame === 'function') {
              requestAnimationFrame(r);
            } else {
              setTimeout(r, 16);
            }
          });
        }
        try { nativeVideo.pause(); } catch (_) {}
      } else {
        for (let frameIndex = 0; frameIndex < totalFrames; frameIndex++) {
          const time = start + frameIndex / fps;
          if (nativeVideo) {
            if (Math.abs(nativeVideo.currentTime - time) > 0.002) {
              await new Promise((resolve) => {
                let done = false;
                const finish = () => {
                  if (!done) {
                    done = true;
                    clearTimeout(timer);
                    nativeVideo.removeEventListener('seeked', finish);
                    nativeVideo.removeEventListener('error', finish);
                    resolve();
                  }
                };
                const timer = setTimeout(finish, 200);
                nativeVideo.addEventListener('seeked', finish, { once: true });
                nativeVideo.addEventListener('error', finish, { once: true });
                nativeVideo.currentTime = time;
              });
            }
            if (player._nativePairs && player._nativePairs.length >= 2) {
              player._nativePairs[0].getContext('2d').drawImage(nativeVideo, 0, 0, 1280, 480, 0, 0, 1280, 480);
              player._nativePairs[1].getContext('2d').drawImage(nativeVideo, 0, 480, 1280, 480, 0, 0, 1280, 480);
              player.lastFrFrame = player._nativePairs[p0FrNative ? 0 : 1];
              player.lastLrFrame = player._nativePairs[p0FrNative ? 1 : 0];
            }
          }

          this.renderFrame(canvas, {
            view: view,
            overlays: overlays,
            speedUnit: speedUnit,
            time: time,
            fr: player.lastFrFrame,
            lr: player.lastLrFrame,
            telemetry: parser ? parser.getTelemetryAtTime(time, manifest.startMonotonicUs) : null,
            mapping: mapping,
            manifest: manifest,
            map: player?.liveMap
          });

          const track = stream.getVideoTracks ? stream.getVideoTracks()[0] : null;
          if (track && typeof track.requestFrame === 'function') {
            track.requestFrame();
          }

          progress(0.1 + 0.85 * (frameIndex + 1) / totalFrames, `Recording video · ${Math.round(100 * (frameIndex + 1) / totalFrames)}%`);
          await new Promise(r => setTimeout(r, Math.max(2, Math.round(frameDelayMs / 2))));
        }
      }

      progress(0.96, 'Finalizing video…');
      const stopPromise = new Promise(resolve => {
        recorder.onstop = resolve;
      });
      recorder.stop();
      await stopPromise;

      const blob = new Blob(chunks, { type: mimeType });
      const arrayBuffer = await blob.arrayBuffer();
      const ext = mimeType.includes('mp4') ? 'mp4' : 'webm';

      progress(1, 'Ready to save');
      return {
        buffer: arrayBuffer,
        fileName: `BimmerVision-${manifest.id.slice(0, 8)}-${view}${requested > 0 ? '-' + requested + 's' : ''}.${ext}`,
        totalFrames,
        duration
      };
    } finally {
      if (recorder.state !== 'inactive') {
        try { recorder.stop(); } catch (_) {}
      }
    }
  }

  /**
   * Render a complete composite frame (cameras + HUD overlays) to a canvas.
   * Shared by the export encoder loop and live modal preview.
   */
  renderFrame(targetCanvas, options = {}) {
    const overlays = options.overlays != null ? options.overlays : (options.includeHud !== false ? {
      blinkers: true,
      speed: true,
      speedLimit: true,
      steering: true,
      brake: true,
      gas: true,
      time: true,
      map: true
    } : null);

    const includeMap = overlays ? (overlays.map !== undefined ? Boolean(overlays.map) : Boolean(options.includeMap)) : false;
    const hasTelemetryBar = overlays ? (overlays.includeHud !== false && (
      overlays.blinkers !== false ||
      overlays.speed !== false ||
      overlays.speedLimit !== false ||
      overlays.steering !== false ||
      overlays.brake !== false ||
      overlays.gas !== false ||
      overlays.time !== false
    )) : false;

    const exportW = includeMap ? 1920 : 1280;
    const barH = includeMap ? 120 : 80;
    const exportH = includeMap ? (hasTelemetryBar ? 1080 : 960) : (hasTelemetryBar ? 1040 : 960);

    try {
      if (targetCanvas.width !== exportW) targetCanvas.width = exportW;
      if (targetCanvas.height !== exportH) targetCanvas.height = exportH;
    } catch (_) {}

    const ctx = targetCanvas.getContext('2d');
    const w = targetCanvas.width || exportW;
    const h = targetCanvas.height || exportH;
    const view = options.view || 'quad';
    const fr = options.fr;
    const lr = options.lr;
    const mapping = options.mapping || (this.player ? this.player.cameraMapping : { phase0: 'frontRear', flipHalves: false });
    const x0 = mapping?.flipHalves ? 640 : 0;
    const x1 = mapping?.flipHalves ? 0 : 640;

    ctx.save();
    ctx.fillStyle = '#0a0c10';
    ctx.fillRect(0, 0, w, h);

    if (view === 'quad') {
      if (fr) {
        try {
          ctx.drawImage(fr, x0, 0, 640, 480, 0, 0, 640, 480);
          ctx.drawImage(fr, x1, 0, 640, 480, 640, 0, 640, 480);
        } catch (_) {}
      }
      if (lr) {
        try {
          ctx.drawImage(lr, x0, 0, 640, 480, 0, 480, 640, 480);
          ctx.drawImage(lr, x1, 0, 640, 480, 640, 480, 640, 480);
        } catch (_) {}
      }
      this._drawQuadLabels(ctx);
    } else if (view === 'source') {
      if (fr) {
        try { ctx.drawImage(fr, 0, 0, 1280, 480, 0, 0, 1280, 480); } catch (_) {}
      }
      if (lr) {
        try { ctx.drawImage(lr, 0, 0, 1280, 480, 0, 480, 1280, 480); } catch (_) {}
      }
    } else {
      const isFrontRear = ['front', 'rear'].includes(view);
      const isSecondHalf = ['rear', 'right'].includes(view);
      const image = isFrontRear ? fr : lr;
      const cropX = isSecondHalf ? x1 : x0;
      if (image) {
        try {
          ctx.drawImage(image, cropX, 0, 640, 480, 0, 0, 1280, 960);
        } catch (_) {}
      } else {
        ctx.fillStyle = '#11141c';
        ctx.fillRect(0, 0, 1280, 960);
        ctx.fillStyle = '#94a3b8';
        ctx.font = 'bold 32px -apple-system, BlinkMacSystemFont, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(`${view.toUpperCase()} CAMERA`, 640, 480);
        ctx.textAlign = 'left';
      }
    }

    const telem = options.telemetry || (this.player?.parser && options.time != null && this.player?.manifest?.startMonotonicUs != null
      ? this.player.parser.getTelemetryAtTime(options.time, this.player.manifest.startMonotonicUs)
      : null);
    const speedUnit = options.speedUnit || this.player?.speedUnit || 'mph';
    const timeSec = options.time != null ? options.time : (this.player?.currentTime || 0);
    const manifest = options.manifest || this.player?.manifest;

    // Draw route map alongside cameras if requested
    if (includeMap) {
      const liveMap = options.map || this.player?.liveMap;
      if (liveMap && typeof liveMap.drawTo === "function") {
        liveMap.drawTo(ctx, 1280, 0, 640, 960, timeSec);
      } else {
        this._drawFallbackMap(ctx, 1280, 0, 640, 960, telem, timeSec, manifest);
      }

      // Vertical divider between cameras and map
      ctx.save();
      ctx.strokeStyle = "rgba(255, 255, 255, 0.15)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(1280, 0);
      ctx.lineTo(1280, 960);
      ctx.stroke();
      ctx.restore();
    }

    // Draw dedicated telemetry console bar below camera playback
    if (hasTelemetryBar) {
      this._drawTelemetryOverlay(ctx, w, 960, barH, telem, speedUnit, timeSec, overlays, manifest);
    }
    ctx.restore();
  }

  renderPreview(targetCanvas, options = {}) {
    this.renderFrame(targetCanvas, options);
  }

  _drawQuadLabels(ctx) {
    ctx.save();
    ctx.font = "bold 20px -apple-system, BlinkMacSystemFont, sans-serif";
    const drawBadge = (text, x, y) => {
      ctx.fillStyle = "rgba(10, 12, 16, 0.75)";
      ctx.beginPath();
      ctx.roundRect(x, y, 96, 32, 6);
      ctx.fill();
      ctx.strokeStyle = "rgba(255, 255, 255, 0.18)";
      ctx.lineWidth = 1;
      ctx.stroke();
      ctx.fillStyle = "#ffffff";
      ctx.fillText(text, x + 16, y + 23);
    };

    drawBadge("FRONT", 20, 20);
    drawBadge("REAR", 660, 20);
    drawBadge("LEFT", 20, 500);
    drawBadge("RIGHT", 660, 500);

    // Dividers
    ctx.strokeStyle = "rgba(255, 255, 255, 0.15)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(640, 0);
    ctx.lineTo(640, 960);
    ctx.moveTo(0, 480);
    ctx.lineTo(1280, 480);
    ctx.stroke();
    ctx.restore();
  }

  _drawTelemetryOverlay(ctx, w, arg3, arg4, telemArg, unitArg, timeSecArg, overlaysArg, manifestArg) {
    let barY = 960;
    let barH = 80;
    let telem = telemArg;
    let unit = unitArg || "mph";
    let timeSec = timeSecArg || 0;
    let overlays = overlaysArg || {};
    let manifest = manifestArg || null;

    if (typeof arg3 === "number" && typeof arg4 === "number") {
      barY = arg3;
      barH = arg4;
    } else {
      // Backward compatibility: (ctx, w, h, telem, unit, timeSec, overlays, manifest)
      const h = arg3;
      telem = arg4;
      unit = telemArg || "mph";
      timeSec = unitArg || 0;
      overlays = timeSecArg || {};
      manifest = overlaysArg || null;
      barY = 960;
      barH = Math.max(48, (h || 1040) - 960);
    }

    if (overlays.includeHud === false) return;

    const ov = {
      blinkers: overlays.blinkers !== false,
      speed: overlays.speed !== false,
      speedLimit: overlays.speedLimit !== false,
      steering: overlays.steering !== false,
      brake: overlays.brake !== false,
      gas: overlays.gas !== false,
      time: overlays.time !== false,
    };

    const anyActive = ov.blinkers || ov.speed || ov.speedLimit || ov.steering || ov.brake || ov.gas || ov.time;
    if (!anyActive) return;

    // RULE: If ANY metadata is visible other than current time, the BimmerVision logo should be visible in the blinker bar.
    const hasOtherMetadata = Boolean(ov.blinkers || ov.speed || ov.speedLimit || ov.steering || ov.brake || ov.gas);
    const showLogo = hasOtherMetadata;

    if (!telem) {
      telem = { speedKph: 0, speedMph: 0, brakePressed: false, acceleratorPercent: 0, steeringAngleDeg: 0, indicator: "off", speedLimit: null };
    }

    ctx.save();

    // Draw functions for each cockpit component
    const indStr = String(telem.indicator || telem.blinker || "off").toLowerCase();
    const isLeftTurn = indStr === 'left' || indStr === 'both' || indStr === 'hazard' || indStr.includes('links') || indStr === 'l';
    const isRightTurn = indStr === 'right' || indStr === 'both' || indStr === 'hazard' || indStr.includes('rechts') || indStr === 'r';
    // Automotive blinking cadence: 1.5 Hz (0.667s period: 333ms ON, 333ms OFF)
    const isBlinkerFlashOn = (timeSec % 0.667) < 0.333;

    const drawBlinkerLeft = (x, centerY) => {
      const active = isLeftTurn && isBlinkerFlashOn;
      ctx.save();
      if (active) {
        ctx.shadowColor = '#38D47A';
        ctx.shadowBlur = 12;
        ctx.fillStyle = '#38D47A';
      } else {
        ctx.fillStyle = 'rgba(160, 170, 195, 0.35)';
      }
      ctx.beginPath();
      const ax = x + 2, ay = centerY;
      ctx.moveTo(ax, ay);
      ctx.lineTo(ax + 16, ay - 13);
      ctx.lineTo(ax + 16, ay - 5);
      ctx.lineTo(ax + 30, ay - 5);
      ctx.lineTo(ax + 30, ay + 5);
      ctx.lineTo(ax + 16, ay + 5);
      ctx.lineTo(ax + 16, ay + 13);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    };

    const drawBlinkerRight = (x, centerY) => {
      const active = isRightTurn && isBlinkerFlashOn;
      ctx.save();
      if (active) {
        ctx.shadowColor = '#38D47A';
        ctx.shadowBlur = 12;
        ctx.fillStyle = '#38D47A';
      } else {
        ctx.fillStyle = 'rgba(160, 170, 195, 0.35)';
      }
      ctx.beginPath();
      const ax = x + 2, ay = centerY;
      ctx.moveTo(ax + 30, ay);
      ctx.lineTo(ax + 14, ay - 13);
      ctx.lineTo(ax + 14, ay - 5);
      ctx.lineTo(ax, ay - 5);
      ctx.lineTo(ax, ay + 5);
      ctx.lineTo(ax + 14, ay + 5);
      ctx.lineTo(ax + 14, ay + 13);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    };

    const drawSpeedCluster = (x, centerY) => {
      let curX = x;
      if (ov.speed) {
        const speed = unit === "mph" ? (telem.speedMph ?? 0) : (telem.speedKph ?? 0);
        ctx.fillStyle = "#ffffff";
        ctx.font = "bold 44px -apple-system, BlinkMacSystemFont, sans-serif";
        ctx.fillText(`${speed}`, curX, centerY + 15);
        const spdW = (speed >= 100 ? 70 : speed >= 10 ? 48 : 28);
        ctx.fillStyle = "rgba(160, 170, 195, 0.85)";
        ctx.font = "bold 15px -apple-system, BlinkMacSystemFont, sans-serif";
        ctx.fillText(unit.toUpperCase(), curX + spdW + 6, centerY + 13);
        curX += spdW + 44;
      }
      if (ov.speedLimit) {
        const bw = 46, bh = 54;
        const bx = curX + (ov.speed ? 8 : 0);
        const by = centerY - Math.round(bh / 2);
        ctx.fillStyle = "#ffffff";
        ctx.beginPath();
        ctx.roundRect(bx, by, bw, bh, 6);
        ctx.fill();
        ctx.strokeStyle = "#c01025";
        ctx.lineWidth = 3;
        ctx.stroke();
        ctx.fillStyle = "#333333";
        ctx.font = "bold 10px -apple-system, BlinkMacSystemFont, sans-serif";
        ctx.fillText("SPEED", bx + 7, by + 14);
        ctx.fillStyle = "#0c0e14";
        ctx.font = "bold 22px -apple-system, BlinkMacSystemFont, sans-serif";
        let limitVal = telem.speedLimit;
        let limitUnit = telem.speedLimitUnit || "mph";
        if (limitVal == null && this.player?.currentSpeedLimit) {
          limitVal = this.player.currentSpeedLimit.limit;
          limitUnit = this.player.currentSpeedLimit.unit || "mph";
        }
        if (limitVal != null) {
          if (unit === "km/h" && limitUnit === "mph") {
            limitVal = Math.round(limitVal * 1.60934);
          } else if (unit === "mph" && limitUnit === "km/h") {
            limitVal = Math.round(limitVal * 0.621371);
          }
        }
        const limitStr = limitVal != null ? String(limitVal) : "—";
        const lw = ctx.measureText ? ctx.measureText(limitStr).width : 14;
        ctx.fillText(limitStr, bx + Math.max(4, Math.round((bw - lw) / 2)), by + 39);
      }
    };

    const drawSteering = (x, centerY) => {
      const angleDeg = telem.steeringAngleDeg || 0;
      const angleRad = (angleDeg * Math.PI) / 180;
      const cx = x + 26;
      const cy = centerY;
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(angleRad);
      if (ClipExporter.assets.wheel && ClipExporter.assets.wheel.complete && ClipExporter.assets.wheel.naturalWidth) {
        try {
          ctx.drawImage(ClipExporter.assets.wheel, -24, -24, 48, 48);
        } catch (_) {}
      } else {
        // High-fidelity vector steering wheel
        ctx.strokeStyle = "#c8d0e0";
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(0, 0, 24, 0, Math.PI * 2);
        ctx.stroke();
        ctx.fillStyle = "#1e222d";
        ctx.beginPath();
        ctx.arc(0, 0, 9, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = "#3da8f2";
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.strokeStyle = "#8a94a6";
        ctx.lineWidth = 3.5;
        ctx.beginPath();
        ctx.moveTo(-24, 0); ctx.lineTo(-9, 0);
        ctx.moveTo(24, 0); ctx.lineTo(9, 0);
        ctx.moveTo(0, 9); ctx.lineTo(0, 24);
        ctx.stroke();
      }
      ctx.restore();
    };

    const drawBrandLogo = (x, centerY) => {
      ctx.save();
      if (ClipExporter.assets.wordmark && ClipExporter.assets.wordmark.complete && ClipExporter.assets.wordmark.naturalWidth) {
        try {
          const img = ClipExporter.assets.wordmark;
          const aspect = img.naturalWidth / img.naturalHeight;
          const h = 32;
          const w = h * aspect;
          ctx.drawImage(img, x, centerY - h / 2, w, h);
        } catch (_) {}
      } else if (ClipExporter.assets.eye && ClipExporter.assets.eye.complete && ClipExporter.assets.eye.naturalWidth) {
        try {
          const img = ClipExporter.assets.eye;
          const aspect = img.naturalWidth / img.naturalHeight;
          const h = 36;
          const w = h * aspect;
          ctx.drawImage(img, x, centerY - h / 2, w, h);
          ctx.fillStyle = "#ffffff";
          ctx.font = "bold 16px -apple-system, BlinkMacSystemFont, sans-serif";
          ctx.fillText("BIMMERVISION", x + w + 8, centerY + 6);
        } catch (_) {}
      } else {
        // High-fidelity vector BimmerVision logo mark
        ctx.fillStyle = "rgba(61, 168, 242, 0.25)";
        ctx.beginPath();
        ctx.arc(x + 16, centerY, 13, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = "#3da8f2";
        ctx.lineWidth = 2.5;
        ctx.stroke();
        ctx.fillStyle = "#3da8f2";
        ctx.beginPath();
        ctx.arc(x + 16, centerY, 5, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = "#ffffff";
        ctx.font = "bold 18px -apple-system, BlinkMacSystemFont, sans-serif";
        ctx.fillText("BIMMER", x + 36, centerY + 6);
        ctx.fillStyle = "#3da8f2";
        ctx.fillText("VISION", x + 110, centerY + 6);
      }
      ctx.restore();
    };

    const drawPedals = (x, centerY) => {
      let px = x;
      if (ov.brake) {
        const isBrake = Boolean(telem.brakePressed);
        ctx.save();
        if (isBrake) {
          ctx.shadowColor = "#EE2440";
          ctx.shadowBlur = 14;
          ctx.fillStyle = "rgba(238, 36, 64, 0.4)";
        } else {
          ctx.fillStyle = "rgba(35, 38, 48, 0.75)";
        }
        ctx.beginPath();
        ctx.roundRect(px, centerY - 16, 50, 32, 5);
        ctx.fill();
        ctx.strokeStyle = isBrake ? "#EE2440" : "rgba(160, 170, 195, 0.55)";
        ctx.lineWidth = 2;
        ctx.stroke();

        ctx.fillStyle = isBrake ? "#EE2440" : "rgba(120, 130, 150, 0.65)";
        ctx.fillRect(px + 21, centerY - 26, 8, 10);

        ctx.strokeStyle = isBrake ? "#ffffff" : "rgba(160, 170, 195, 0.75)";
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(px + 10, centerY - 6); ctx.lineTo(px + 40, centerY - 6);
        ctx.moveTo(px + 10, centerY + 3); ctx.lineTo(px + 40, centerY + 3);
        ctx.stroke();

        ctx.fillStyle = isBrake ? "#EE2440" : "rgba(160, 170, 195, 0.85)";
        ctx.font = "bold 11px -apple-system, BlinkMacSystemFont, sans-serif";
        ctx.fillText("BRAKE", px + 7, centerY + 28);
        ctx.restore();
        px += 58;
      }

      if (ov.gas) {
        const isGas = Boolean(telem.gasPressed || (telem.acceleratorPercent ?? 0) > 5);
        ctx.save();
        if (isGas) {
          ctx.shadowColor = "#38D47A";
          ctx.shadowBlur = 14;
          ctx.fillStyle = "rgba(56, 212, 122, 0.4)";
        } else {
          ctx.fillStyle = "rgba(35, 38, 48, 0.75)";
        }
        ctx.beginPath();
        ctx.roundRect(px + 4, centerY - 22, 26, 42, 5);
        ctx.fill();
        ctx.strokeStyle = isGas ? "#38D47A" : "rgba(160, 170, 195, 0.55)";
        ctx.lineWidth = 2;
        ctx.stroke();

        ctx.fillStyle = isGas ? "#38D47A" : "rgba(120, 130, 150, 0.65)";
        ctx.fillRect(px, centerY + 17, 34, 5);

        ctx.strokeStyle = isGas ? "#ffffff" : "rgba(160, 170, 195, 0.75)";
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(px + 12, centerY - 15); ctx.lineTo(px + 12, centerY + 9);
        ctx.moveTo(px + 22, centerY - 15); ctx.lineTo(px + 22, centerY + 9);
        ctx.stroke();

        ctx.fillStyle = isGas ? "#38D47A" : "rgba(160, 170, 195, 0.85)";
        ctx.font = "bold 11px -apple-system, BlinkMacSystemFont, sans-serif";
        ctx.fillText("GAS", px + 9, centerY + 32);
        ctx.restore();
      }
    };

    const drawTime = (x, centerY) => {
      ctx.save();
      const startMs = manifest?.startedAt ? new Date(manifest.startedAt).getTime() : (this.player?.manifest?.startedAt ? new Date(this.player.manifest.startedAt).getTime() : NaN);
      if (!isNaN(startMs)) {
        const curDate = new Date(startMs + timeSec * 1000);
        const dateStr = curDate.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
        const timeStr = curDate.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit", second: "2-digit" });
        ctx.font = "bold 13px -apple-system, BlinkMacSystemFont, sans-serif";
        ctx.fillStyle = "rgba(180, 195, 220, 0.9)";
        ctx.fillText(dateStr, x, centerY - 8);
        ctx.font = "bold 16px monospace";
        ctx.fillStyle = "#ffffff";
        ctx.fillText(timeStr, x, centerY + 13);
      } else {
        ctx.fillStyle = "rgba(255, 255, 255, 0.9)";
        ctx.font = "bold 17px monospace";
        const mins = Math.floor(timeSec / 60);
        const secs = (timeSec % 60).toFixed(2).padStart(5, "0");
        const timeStr = `${String(mins).padStart(2, "0")}:${secs}`;
        ctx.fillText(timeStr, x, centerY + 6);
      }
      ctx.restore();
    };

    const hasDate = Boolean(manifest?.startedAt || this.player?.manifest?.startedAt);
    const timeWidth = hasDate ? 128 : 96;

    // 1. Left cluster: Speed & Speed Limit
    const leftModules = [];
    if (ov.speed || ov.speedLimit) {
      let w = 0;
      if (ov.speed) {
        const spd = unit === "mph" ? (telem.speedMph ?? 0) : (telem.speedKph ?? 0);
        w += (spd >= 100 ? 118 : spd >= 10 ? 96 : 76);
      }
      if (ov.speedLimit) w += (ov.speed ? 60 : 50);
      leftModules.push({ id: 'speed', width: w, draw: drawSpeedCluster });
    }

    // 2. Center cluster: Blinker Left | Steering Wheel | Blinker Right (matching web hud-center)
    const centerModules = [];
    if (ov.blinkers) {
      centerModules.push({ id: 'blinker_left', width: 36, draw: drawBlinkerLeft });
    }
    if (ov.steering) {
      centerModules.push({ id: 'steering', width: 56, draw: drawSteering });
    }
    if (ov.blinkers) {
      centerModules.push({ id: 'blinker_right', width: 36, draw: drawBlinkerRight });
    }

    // 3. Right cluster: Pedals (Brake/Gas) | BimmerVision Logo | Time (matching web hud-right)
    const rightModules = [];
    if (ov.brake || ov.gas) {
      let w = 0;
      if (ov.brake) w += 64;
      if (ov.gas) w += 44;
      rightModules.push({ id: 'pedals', width: w, draw: drawPedals });
    }
    if (showLogo) {
      rightModules.push({ id: 'logo', width: 184, draw: drawBrandLogo });
    }
    if (ov.time) {
      rightModules.push({ id: 'time', width: timeWidth, draw: drawTime });
    }

    const totalCount = leftModules.length + centerModules.length + rightModules.length;
    if (totalCount === 0) {
      ctx.restore();
      return;
    }

    // Draw full-width bottom dashboard bar background below camera area
    ctx.fillStyle = "rgba(12, 14, 20, 0.98)";
    ctx.beginPath();
    ctx.roundRect(0, barY, w, barH, 0);
    ctx.fill();
    ctx.strokeStyle = "rgba(255, 255, 255, 0.14)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, barY);
    ctx.lineTo(w, barY);
    ctx.stroke();

    const centerY = barY + Math.round(barH / 2);
    const gap = 24;
    const paddingX = w > 1280 ? 56 : 36;

    // Special case: Only Time is enabled (single module)
    if (totalCount === 1 && rightModules.length === 1 && rightModules[0].id === 'time') {
      const tx = Math.round((w - timeWidth) / 2);
      drawTime(tx, centerY);
      ctx.restore();
      return;
    }

    // Draw Left cluster
    let curLeftX = paddingX;
    for (const mod of leftModules) {
      mod.draw(curLeftX, centerY);
      curLeftX += mod.width + gap;
    }

    // Draw Center cluster
    if (centerModules.length > 0) {
      const centerTotalW = centerModules.reduce((acc, m) => acc + m.width, 0) + (centerModules.length - 1) * gap;
      let curCenterX = Math.round((w - centerTotalW) / 2);
      for (const mod of centerModules) {
        mod.draw(curCenterX, centerY);
        curCenterX += mod.width + gap;
      }
    }

    // Draw Right cluster
    if (rightModules.length > 0) {
      const rightTotalW = rightModules.reduce((acc, m) => acc + m.width, 0) + (rightModules.length - 1) * gap;
      let curRightX = w - paddingX - rightTotalW;
      for (const mod of rightModules) {
        mod.draw(curRightX, centerY);
        curRightX += mod.width + gap;
      }
    }

    ctx.restore();
  }

  _drawFallbackMap(ctx, x, y, w, h, telem, timeSec, manifest) {
    ctx.save();
    ctx.beginPath();
    ctx.rect(x, y, w, h);
    ctx.clip();
    ctx.translate(x, y);

    // Dark base
    ctx.fillStyle = "#121214";
    ctx.fillRect(0, 0, w, h);

    // Vector grid
    ctx.strokeStyle = "rgba(255, 255, 255, 0.05)";
    ctx.lineWidth = 1;
    for (let gx = 0; gx <= w; gx += 64) {
      ctx.beginPath();
      ctx.moveTo(gx, 0); ctx.lineTo(gx, h);
      ctx.stroke();
    }
    for (let gy = 0; gy <= h; gy += 64) {
      ctx.beginPath();
      ctx.moveTo(0, gy); ctx.lineTo(w, gy);
      ctx.stroke();
    }

    const route = (this.player?.parser && manifest?.startMonotonicUs != null)
      ? this.player.parser.getRouteSeries(manifest.startMonotonicUs)
      : (this.player?.routeSeries || []);

    if (route && route.length > 1) {
      let minLat = Infinity, maxLat = -Infinity;
      let minLon = Infinity, maxLon = -Infinity;
      for (const pt of route) {
        if (pt.latitude < minLat) minLat = pt.latitude;
        if (pt.latitude > maxLat) maxLat = pt.latitude;
        if (pt.longitude < minLon) minLon = pt.longitude;
        if (pt.longitude > maxLon) maxLon = pt.longitude;
      }
      const pad = 48;
      const dLat = (maxLat - minLat) || 0.001;
      const dLon = (maxLon - minLon) || 0.001;
      const mapX = (lon) => pad + ((lon - minLon) / dLon) * (w - pad * 2);
      const mapY = (lat) => h - pad - ((lat - minLat) / dLat) * (h - pad * 2);

      ctx.beginPath();
      route.forEach((pt, idx) => {
        const px = mapX(pt.longitude);
        const py = mapY(pt.latitude);
        if (idx === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      });
      ctx.strokeStyle = "rgba(61, 168, 242, 0.4)";
      ctx.lineWidth = 6;
      ctx.stroke();

      ctx.strokeStyle = "#3da8f2";
      ctx.lineWidth = 3;
      ctx.stroke();

      const lat = telem?.latitude ?? route[0].latitude;
      const lon = telem?.longitude ?? route[0].longitude;
      const vx = mapX(lon);
      const vy = mapY(lat);

      ctx.fillStyle = "#38D47A";
      ctx.beginPath();
      ctx.arc(vx, vy, 8, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "#ffffff";
      ctx.lineWidth = 2;
      ctx.stroke();
    } else {
      ctx.fillStyle = "rgba(255, 255, 255, 0.44)";
      ctx.font = "14px -apple-system, BlinkMacSystemFont, sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText("GPS Route Map", w / 2, h / 2);
    }

    if (telem && telem.latitude != null && telem.longitude != null) {
      const coordText = `${telem.latitude.toFixed(5)}°, ${telem.longitude.toFixed(5)}°`;
      ctx.fillStyle = "rgba(11, 11, 12, 0.88)";
      ctx.beginPath();
      ctx.roundRect(16, 16, 180, 26, 4);
      ctx.fill();
      ctx.strokeStyle = "rgba(255, 255, 255, 0.15)";
      ctx.lineWidth = 1;
      ctx.stroke();
      ctx.fillStyle = "#ffffff";
      ctx.font = "bold 11px -apple-system, BlinkMacSystemFont, sans-serif";
      ctx.textAlign = "left";
      ctx.textBaseline = "middle";
      ctx.fillText(coordText, 24, 29);
    }

    ctx.font = "9px -apple-system, BlinkMacSystemFont, sans-serif";
    ctx.fillStyle = "rgba(255, 255, 255, 0.45)";
    ctx.textAlign = "left";
    ctx.textBaseline = "bottom";
    ctx.fillText("© OpenStreetMap", 12, h - 10);

    ctx.restore();
  }

  _extractDecoderConfigFromChunk(chunk) {
    if (!chunk) return null;
    try {
      const byteLen = chunk.byteLength || (chunk.data ? chunk.data.byteLength : 0);
      if (!byteLen) return null;
      const data = new Uint8Array(byteLen);
      if (typeof chunk.copyTo === "function") {
        chunk.copyTo(data);
      } else if (chunk.data) {
        data.set(new Uint8Array(chunk.data));
      }
      if (data.length === 0) return null;

      let sps = null;
      let pps = null;

      // Scan for Annex B NAL start codes [0, 0, 0, 1] or [0, 0, 1]
      for (let i = 0; i < data.length - 4; i++) {
        let nalStart = -1;
        if (data[i] === 0 && data[i + 1] === 0 && data[i + 2] === 1) {
          nalStart = i + 3;
        } else if (data[i] === 0 && data[i + 1] === 0 && data[i + 2] === 0 && data[i + 3] === 1) {
          nalStart = i + 4;
        }
        if (nalStart > 0) {
          const nalType = data[nalStart] & 31;
          let nextStart = data.length;
          for (let j = nalStart; j < data.length - 3; j++) {
            if (data[j] === 0 && data[j + 1] === 0 && (data[j + 2] === 1 || (data[j + 2] === 0 && data[j + 3] === 1))) {
              nextStart = j;
              break;
            }
          }
          const nal = data.subarray(nalStart, nextStart);
          if (nalType === 7 && !sps) sps = nal;
          if (nalType === 8 && !pps) pps = nal;
        }
      }

      // If AVCC format (4-byte length prefixes)
      if (!sps && !pps && data.length > 8) {
        let offset = 0;
        while (offset + 4 < data.length) {
          const len = (data[offset] << 24) | (data[offset + 1] << 16) | (data[offset + 2] << 8) | data[offset + 3];
          offset += 4;
          if (len <= 0 || offset + len > data.length) break;
          const nal = data.subarray(offset, offset + len);
          const type = nal[0] & 31;
          if (type === 7 && !sps) sps = nal;
          if (type === 8 && !pps) pps = nal;
          offset += len;
        }
      }

      if (sps && pps && typeof RtpH264Assembler !== "undefined") {
        return {
          codec: "avc1.640028",
          description: RtpH264Assembler.makeAvcC(sps, pps),
          colorSpace: {
            primaries: "bt709",
            transfer: "bt709",
            matrix: "bt709",
            fullRange: false
          }
        };
      }
    } catch (_) {}
    return null;
  }
}

// Preload browser image assets if running in browser
if (typeof Image !== 'undefined') {
  try {
    const w = new Image(); w.src = 'assets/wheel-face.png'; ClipExporter.assets.wheel = w;
    const wm = new Image(); wm.src = 'assets/bimmervision-wordmark.png'; ClipExporter.assets.wordmark = wm;
    const eye = new Image(); eye.src = 'assets/bimmervision-eye.png'; ClipExporter.assets.eye = eye;
  } catch (_) {}
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = { ClipExporter };
}
