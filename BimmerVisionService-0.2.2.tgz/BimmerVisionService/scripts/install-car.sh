#!/bin/sh
# Run deliberately on the enrolled car; --stage-root is an offline packaging check.
set -euo pipefail
bundle="$(CDPATH='' cd -- "$(dirname -- "$0")/.." && pwd)"
stage_root=""
enrollment="/var/opt/bimmervision-service/current/hardware.json"
if [ ! -f "$enrollment" ] && [ -f "/var/opt/masel-cameras-live/current/hardware.json" ]; then
  enrollment="/var/opt/masel-cameras-live/current/hardware.json"
fi
tls_dir=""
while [ "$#" -gt 0 ]; do
  case "$1" in
    --bundle) bundle="$2"; shift 2 ;;
    --stage-root) stage_root="$2"; shift 2 ;;
    --enrollment) enrollment="$2"; shift 2 ;;
    --tls-dir) tls_dir="$2"; shift 2 ;;
    *) echo "Usage: install-car.sh [--bundle DIR] [--enrollment FILE] [--tls-dir DIR] [--stage-root DIR]" >&2; exit 2 ;;
  esac
done
node_bin="${BV_NODE:-node}"
if [ -z "$stage_root" ]; then
  [ "$(uname -s)" = Linux ] && [ "$(id -u)" -eq 0 ] || { echo "Live install requires root on the enrolled Linux head unit." >&2; exit 1; }
  command -v systemctl >/dev/null || { echo "systemctl is required" >&2; exit 1; }
fi
[ -f "$bundle/companion/main.js" ] && [ -f "$bundle/companion/receiver" ] || { echo "Incomplete car bundle" >&2; exit 1; }
[ -f "$enrollment" ] && [ ! -L "$enrollment" ] || { echo "Verified hardware enrollment required" >&2; exit 1; }
"$node_bin" -e 'var fs=require("fs"),c=JSON.parse(fs.readFileSync(process.argv[1],"utf8"));if(c.hardwareTest!==true||c.adapterVerified!==true||!Number.isInteger(c.uid)||c.uid<1){process.stderr.write("Verified hardware enrollment required\n");process.exit(1);}' "$enrollment"
for source_file in "$bundle"/companion/*.js; do "$node_bin" --check "$source_file" >/dev/null; done
base="$stage_root/var/opt/bimmervision-service"
[ ! -L "$base" ] || { echo "Refusing symlink install root" >&2; exit 1; }
mkdir -p "$base/releases"
car_version="0.2.0"
if [ -f "$bundle/companion/version.json" ]; then
  car_version="$("$node_bin" -e 'var v=require(process.argv[1]).version;if(!/^[0-9]+\.[0-9]+\.[0-9]+$/.test(v))throw Error("Invalid car version");process.stdout.write(v);' "$bundle/companion/version.json")"
fi
release="$base/releases/$car_version-$(date +%Y%m%d%H%M%S)-$$"
[ ! -e "$release" ] || { echo "Release already exists" >&2; exit 1; }
mkdir -m 755 "$release"
cp -R "$bundle/companion/." "$release/"
cp "$enrollment" "$release/hardware.json"
chmod 600 "$release/hardware.json"
chmod 755 "$release/receiver"
if [ -n "$tls_dir" ]; then
  [ -f "$tls_dir/key.pem" ] && [ -f "$tls_dir/cert.pem" ] || { echo "TLS directory requires key.pem and cert.pem" >&2; exit 1; }
  mkdir -p "$release/tls"
  chmod 700 "$release/tls"
  cp "$tls_dir/key.pem" "$tls_dir/cert.pem" "$release/tls/"
  chmod 600 "$release/tls/key.pem"
fi
# Snapshot publication and service state before changing an existing installation.
transaction=""
if [ -z "$stage_root" ]; then
  if [ -f "$release/recovery.js" ]; then "$node_bin" "$release/recovery.js"; fi
  transaction="$(mktemp -d "$base/.install-XXXXXX")"
  for link in current previous; do
    if [ -L "$base/$link" ]; then cp -P "$base/$link" "$transaction/$link"; fi
  done
  unit=/etc/systemd/system/bimmervision-service.service
  if [ -e "$unit" ]; then cp -P "$unit" "$transaction/unit"; fi
  recorder_active=0; recorder_enabled=0; legacy_active=0; legacy_enabled=0
  if systemctl is-active --quiet bimmervision-service.service; then recorder_active=1; fi
  if systemctl is-enabled --quiet bimmervision-service.service; then recorder_enabled=1; fi
  if systemctl is-active --quiet masel-cameras-live.service; then legacy_active=1; fi
  if systemctl is-enabled --quiet masel-cameras-live.service; then legacy_enabled=1; fi
  rollback() {
    result=$?
    trap - EXIT
    if [ "$result" -ne 0 ]; then
      systemctl stop bimmervision-service.service || true
      for link in current previous; do
        "$node_bin" -e 'var fs=require("fs"),p=require("path"),base=process.argv[1],snap=process.argv[2],name=process.argv[3],dst=p.join(base,name),src=p.join(snap,name);try{var target=fs.readlinkSync(src),tmp=p.join(base,".rollback-"+name+"-"+process.pid);fs.symlinkSync(target,tmp);fs.renameSync(tmp,dst);}catch(e){if(e.code!=="ENOENT")throw e;try{fs.unlinkSync(dst);}catch(x){if(x.code!=="ENOENT")throw x;}}' "$base" "$transaction" "$link" || true
      done
      if [ -e "$transaction/unit" ] || [ -L "$transaction/unit" ]; then cp -P "$transaction/unit" "$unit"; else rm -f "$unit"; fi
      systemctl daemon-reload || true
      if [ "$recorder_enabled" = 1 ]; then systemctl enable bimmervision-service.service || true; else systemctl disable bimmervision-service.service || true; fi
      if [ "$legacy_enabled" = 1 ]; then systemctl enable masel-cameras-live.service || true; else systemctl disable masel-cameras-live.service || true; fi
      if [ "$recorder_active" = 1 ]; then systemctl restart bimmervision-service.service || true; else systemctl stop bimmervision-service.service || true; fi
      if [ "$legacy_active" = 1 ]; then systemctl start masel-cameras-live.service || true; else systemctl stop masel-cameras-live.service || true; fi
      echo "Install failed; previous release, unit and service states restored." >&2
    fi
    rm -rf "$transaction"
    exit "$result"
  }
  trap rollback EXIT
fi
# Atomic symlink replacement uses rename(2), avoiding mv following current/.
"$node_bin" -e 'var fs=require("fs"),p=require("path"),base=process.argv[1],release=process.argv[2],cur=p.join(base,"current");function set(name,target){var tmp=p.join(base,"."+name+"-"+process.pid);fs.symlinkSync(target,tmp);fs.renameSync(tmp,p.join(base,name));}try{var s=fs.lstatSync(cur);if(!s.isSymbolicLink())throw Error("Refusing non-symlink current release");set("previous",fs.readlinkSync(cur));}catch(e){if(e.code!=="ENOENT")throw e;}set("current",release);' "$base" "$release"
if [ -n "$stage_root" ]; then
  echo "Staged recorder at $base/current; no services changed."
  exit 0
fi
cp "$release/bimmervision-service.service" "$unit"
systemctl daemon-reload
if systemctl cat masel-cameras-live.service >/dev/null 2>&1; then
  systemctl stop masel-cameras-live.service
fi
systemctl enable bimmervision-service.service
# enable --now does not reload an already running process after current changes.
systemctl restart bimmervision-service.service
systemctl is-active --quiet bimmervision-service.service
if systemctl cat masel-cameras-live.service >/dev/null 2>&1; then
  systemctl disable masel-cameras-live.service
fi
echo "Recorder service installed. Install the OAP screen package separately with the existing Store workflow."
