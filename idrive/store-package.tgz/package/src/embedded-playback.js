"use strict";

// Draw inside the app's own iDrive page so BMW popups and cameras keep priority.
function picture(width,height) {
  const h=Math.min(height-96,width*3/4),w=h*4/3;
  return {x:(width-w)/2,y:(height-96-h)/2,w:w,h:h};
}
function tileAt(box,x,y) {
  const p=picture(box.w,box.h);
  if(x<p.x||x>=p.x+p.w||y<p.y||y>=p.y+p.h)return null;
  return (x>=p.x+p.w/2?1:0)+(y>=p.y+p.h/2?2:0);
}
function frame(width, height, position, paused, ended, tile, seekFocus) {
  const words = [];
  function number(value) {
    const data = Buffer.alloc(4);
    data.writeFloatLE(value, 0);
    return data.readUInt32LE(0);
  }
  function shape(op, coords, color) {
    words.push(op, ...coords.map(number), color);
  }
  const white = 0xf5f7faff, blue = 0x54baffff;
  const cy = height - 48, start = 160, end = width - 60;
  const p=picture(width,height);
  words.push(1,0x101215ff,13,...[p.x,p.y,p.w,p.h].map(number));
  const zoom=Number.isInteger(tile),scale=zoom?2:1;
  const left=p.x-(zoom?(tile%2)*p.w:0),top=p.y-(zoom?Math.floor(tile/2)*p.h:0);
  words.push(19,...[left,top,p.w*scale,p.h*scale,0].map(number),1,14);
  const track = seekFocus ? white : 0x8d9298ff;
  shape(4,[36,cy-32,76,64,6],seekFocus ? 0x262a30ff : 0x1769a6ff);
  if (paused || ended) {
    words.push(10, 1);
    [[60,cy-18],[60,cy+18],[90,cy]].forEach(p=>words.push(number(p[0]),number(p[1]),white));
  } else {
    shape(2, [58, cy-18, 10, 36], white);
    shape(2, [78, cy-18, 10, 36], white);
  }
  shape(2,[start, cy-2, end-start, 4],track);
  const x = start + Math.min(1,Math.max(0,position))*(end-start);
  if(x>start) shape(2,[start,cy-2,x-start,4],blue);
  if(seekFocus) shape(4,[x-9,cy-16,18,32,4],blue);
  shape(4,[x-2,cy-10,4,20,2],white);
  const data = Buffer.alloc(words.length*4);
  words.forEach((v,i)=>data.writeUInt32LE(v>>>0,i*4));
  return data;
}

function present(display, file, position, paused, ended, tile, seekFocus) {
  const box = display.embed;
  if(display.boundFile!==file) {
    display.mode=2;
    display.frameOverride=box;
    display.file=file;
    if(!display.boundFile)display.layout();
    else{
      const id=Buffer.alloc(4);id.writeUInt32LE(1,0);
      display.send(13,Buffer.concat([id,Buffer.from(file)]));
    }
    display.boundFile=file;
    const claim=Buffer.alloc(20);
    claim.writeUInt32LE(1,0);
    [0,0,box.w,box.h].forEach((v,i)=>claim.writeFloatLE(v,4+i*4));
    display.send(9,claim);
  }
  if(display.caps&2){
    const grab=Buffer.alloc(8);grab.writeUInt32LE(1,0);grab.writeUInt32LE(3,4);
    display.send(0x4d520002,grab);
  }
  redraw(display,position,paused,ended,tile,seekFocus);
}

function redraw(display,position,paused,ended,tile,seekFocus) {
  if(!display.embed||!display.boundFile)return;
  display.lastVideoFrame=frame(display.embed.w,display.embed.h,position,paused,ended,tile,seekFocus);
  display.send(7,display.lastVideoFrame);
}
module.exports={present,tileAt,redraw};
