#!/bin/sh
# Generate outside capture storage. Copy only through the reviewed installer.
set -eu
if [ "$#" -ne 2 ]; then echo "Usage: $0 PRIVATE_OUTPUT_DIR CAR_WIFI_IPV4" >&2; exit 2; fi
output_dir=$1
car_ipv4=$2
case "$car_ipv4" in *[!0-9.]*|'') echo 'IPv4 address required' >&2; exit 2;; esac
if ! awk -v ip="$car_ipv4" 'BEGIN{n=split(ip,a,".");if(n!=4)exit 1;for(i=1;i<=4;i++)if(a[i]==""||a[i]+0>255)exit 1;exit 0}'; then echo 'Invalid IPv4 address' >&2; exit 2; fi
if [ -e "$output_dir" ]; then echo 'Use a new output directory; existing certificates are never overwritten' >&2; exit 2; fi
umask 077
mkdir -m 700 "$output_dir"
cat > "$output_dir/openssl.cnf" <<CONFIG
[req]
distinguished_name=dn
x509_extensions=ext
prompt=no
[dn]
CN=BimmerVision local recorder
[ext]
subjectAltName=IP:$car_ipv4
basicConstraints=critical,CA:FALSE
keyUsage=critical,digitalSignature,keyEncipherment
extendedKeyUsage=serverAuth
CONFIG
openssl req -x509 -newkey rsa:2048 -nodes -sha256 -days 397 -config "$output_dir/openssl.cnf" -keyout "$output_dir/key.pem" -out "$output_dir/cert.pem"
rm "$output_dir/openssl.cnf"
chmod 600 "$output_dir/key.pem" "$output_dir/cert.pem"
openssl x509 -in "$output_dir/cert.pem" -outform DER | openssl dgst -sha256
