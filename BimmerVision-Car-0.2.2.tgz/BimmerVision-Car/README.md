# BimmerVision car update 0.2.2

Includes the native OAP and matching recorder/web companion.
Use scripts/install-car.sh deliberately on the enrolled car; it installs the companion, not the OAP.
Install masel_cameras@0.2.2.tgz separately through the existing OAP/Store workflow.
Keep existing hardware enrollment and TLS files. No recording deletion is needed.
See docs/INSTALL.md and the car-update report for validation and limitations.
