# Installation and rollback

The rebuild has not been installed or tested on the vehicle. Keep the original
v0.1.4 OAP archive and original `/var/opt/masel-cameras-live` directory available.
Use the existing supported OAP/Store installation workflow; this project does
not invent package signing or hardware enrollment.

## Mac

Unzip `BimmerVision-Mac-0.2.0.zip` and move `BimmerVision.app` into Applications,
or build with `bash scripts/build-mac.sh`. Quit an already running copy before
replacing it. This local build is ad-hoc signed and
not Apple-notarized. Use Finder's normal Open workflow if macOS asks for approval.
Do not disable system-wide security settings. It targets macOS13+ and the packaged
binary architecture is recorded in VERIFICATION.md; source builds use your Mac's
architecture.

Open a downloaded recording bundle, the USB's `BimmerVision` folder, or the supplied
`fixtures/library` folder. The clean synthetic recording contains known camera
labels; the loss fixture intentionally has an unavailable interval.

## Prepare the car bundle on the Mac

Extract `BimmerVision-Car-0.2.0.tgz` into a staging directory. Determine the car's
Wi-Fi IPv4 address from the current working connection, then run:

```sh
bash scripts/generate-tls.sh ./car-tls CAR_WIFI_IPV4
```

Keep `key.pem` private. Copy the car bundle and the generated TLS directory to
the car using your existing secure transfer method. The server uses HTTPS on
port8765, the existing app's transfer port. If the head unit's TLS/runtime cannot
support the server, it stays disabled with an error; recording is independent.
Do not configure a cleartext fallback.

The receiver binary is copied unchanged from the backup and identified by SHA256
in the release manifest. It is a Linux x86-64 program requiring the car's existing
BMW bridge library. It does not run on macOS. Hardware enrollment is deliberately
not pre-enabled in the bundle: reuse the verified enrollment from the same car.

## Install deliberately on the enrolled car

Review the shell script before running it. On the car as root, from the extracted
bundle directory, run:

```sh
bash scripts/install-car.sh --bundle . \
  --enrollment /var/opt/masel-cameras-live/current/hardware.json \
  --tls-dir /PATH/TO/car-tls
```

The installer validates enrollment and JavaScript syntax, installs into a new
versioned `/var/opt/bimmervision-recorder/releases/` directory, points `current`
to it, and retains `previous` when updating. The existing helper directory and
recordings are not deleted. It stops the old live-preview companion and explicitly
restarts `masel-bimmervision-recorder.service`, including during upgrades. On a
failed upgrade it restores the prior release links, unit file and enabled/active
service states; first-install failure restores the original service state.
Review status/journal after
installation and before relying on recording:

```sh
systemctl status masel-bimmervision-recorder.service
journalctl -u masel-bimmervision-recorder.service -n 50 --no-pager
```

Install `masel_cameras@0.2.0.tgz` with the same OAP/Store process used for the
original package. Updating the same app identity preserves the enrolled app uid;
verify the actual uid matches hardware.json. Select the intended USB in the new
screen and enable recording. There is no live camera preview. The USB must already
be mounted and writable; the app never formats a drive or falls back to internal
video storage. Full storage stops recording until capacity is freed.

The companion may reuse read-only telemetry decoding and profiles from the original
helper; retain it. Do not uninstall it as cleanup. Verify exact runtime/service
paths in the packaged service before installing on a differently arranged car.

## Pair a Mac or phone

Stay on **Connect Mac / Phone**. Enter endpoint/code and compare the full certificate
fingerprint to the screen, or paste the QR URL containing all three. Browser QR
users must trust the generated local certificate through their OS/browser's normal
certificate workflow; the QR code does not bypass browser TLS trust. Check that
the code is eight digits and changes after Back and re-entry. A second client
must be rejected while one is paired. Back, focus loss, and app death must close
the server within the lease deadline. Pairing only gates access; it is not proof
of a physical device's identity if its credentials are copied.

## Roll back

On the enrolled car as root:

```sh
bash scripts/rollback-car.sh
```

Then restore `app/masel_cameras@0.1.4.tgz` from the original backup using the
existing Store workflow. This re-enables the original companion. It does not
delete recordings or remove the new release files. Keep both versions until
vehicle acceptance is complete.

## Offline installer check

`--stage-root DIR` writes a simulated installation beneath DIR without calling
systemctl or touching the car. This is exercised by automated tests and is not
a substitute for testing the actual enrolled hardware.

## MGU recovery integration (November 10 correction)

Before starting, stopping, upgrading or rolling back this custom service, its base
name `masel-bimmervision-recorder` must be present in **both** `[Whitelist]` and
`[WhitelistExitSuccess]` of `/etc/recmgr-restartlist.conf`, and the head unit must
have booted after that registration. The vehicle's recovery records showed that
an ordinary successful service stop caused a head-unit recovery reboot when this
registration was missing. Do not restart the recovery manager or disable its
protections globally. Use the installed MGU deployment workflow to register the
service, retaining all existing entries and the entire forced-restart section.

`car/recovery.js` checks registration and provides an idempotent, narrowly scoped
registration transformation. The installer checks registration before service
operations. Registration changed during the current boot requires a head-unit
restart before any service operations. The service also sets `LimitCORE=1` and
bounds repeated startup failures, matching the existing custom-tool deployment
limits. These limits do not replace recovery registration.

USB 3.0 is **not** required. Negotiated link speed is informational. Discovery
attempts to remount physical USB media writable, then verifies the actual mount
flags and device identity before offering it. A failed remount, write-protected
medium, or filesystem error remains unavailable; no drive is formatted or repaired
automatically. A faster link does not establish sustained recording performance.
